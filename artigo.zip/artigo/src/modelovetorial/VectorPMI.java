package modelovetorial;

import java.util.ArrayList;
import java.util.TreeMap;

public class VectorPMI {
	
	ArrayList<Double> vectorPmi;
	String word1;
	ArrayList<String> listaWords;
	TreeMap<String, Double> matriz;
	
	TreeMap<String, Double> matrizLocal;
	

	public VectorPMI(String word1) {
		this.vectorPmi = new ArrayList<Double>();
		this.word1 = word1;
		this.listaWords = new ArrayList<String>();
		this.matrizLocal = new TreeMap<String, Double>();
	}
	
	
	public void montarVector(double pmi, String word) {
		this.vectorPmi.add(pmi);
		this.listaWords.add(word);
	}


	public ArrayList<Double> getVectorPmi() {
		return vectorPmi;
	}


	public void setVectorPmi(ArrayList<Double> vectorPmi) {
		this.vectorPmi = vectorPmi;
	}


	public String getWord1() {
		return word1;
	}


	public void setWord1(String word1) {
		this.word1 = word1;
	}


	public ArrayList<String> getListaWords() {
		return listaWords;
	}


	public void setListaWords(ArrayList<String> listaWords) {
		this.listaWords = listaWords;
	}
	
	public TreeMap<String, Double> getMatriz() {
		return matriz;
	}


	public void setMatriz(TreeMap<String, Double> matriz) {
		this.matriz = matriz;
		//this.matrizLocal = this.matriz;
		
		
		
		for(int i=0; i<this.matriz.size();i++) {
			Object key = this.matriz.keySet().toArray(new Object[this.matriz.size()])[i];
			this.matrizLocal.put((String) key, this.matriz.get(key));
		}
		
		for(int i=0; i<this.vectorPmi.size();i++)
			this.matrizLocal.put(this.listaWords.get(i), this.vectorPmi.get(i));
		
		//System.out.println("set "+this.matrizLocal);
	}


	public TreeMap<String, Double> getMatrizLocal() {
		return matrizLocal;
	}


	public void setMatrizLocal(TreeMap<String, Double> matrizLocal) {
		this.matrizLocal = matrizLocal;
	}

	

}
