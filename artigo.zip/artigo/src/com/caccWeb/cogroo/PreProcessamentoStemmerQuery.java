package com.caccWeb.cogroo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import java.util.ArrayList;
import java.util.Iterator;



import org.apache.lucene.analysis.en.EnglishAnalyzer;
import org.tartarus.snowball.ext.PorterStemmer;

import opennlp.tools.tokenize.Tokenizer;
import opennlp.tools.tokenize.TokenizerME;
import opennlp.tools.tokenize.TokenizerModel;
import opennlp.tools.util.InvalidFormatException;





/**
 * PorterStemAnalyzer processes input
 * text by stemming English words to their roots.
 * This Analyzer also converts the input to lower case
 * and removes stop words.  A small set of default stop
 * words is defined in the STOP_WORDS
 * array, but a caller can specify an alternative set
 * of stop words by calling non-default constructor.
 */
public class PreProcessamentoStemmerQuery  {  
	
	
	
	
	
	public PreProcessamentoStemmerQuery(){
		
		
		
	}
   	
	public ArrayList<String>  stemmer(String query){
		
		
		
		 ArrayList<String> queryListStem = new ArrayList<String>();
		
		 String array[];
		 array = query.split(" ");
		 
		 
		  PorterStemmer stem = new PorterStemmer();
		  
		  for(int i=0;i<array.length;i++){
			  			 					
				stem.setCurrent(array[i]);
				stem.stem();
				queryListStem.add(stem.getCurrent());
						  
		  }	

		  
		  return queryListStem;
	}
	
   
}  
  
