package com.caccWeb.arquivo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import javax.faces.context.FacesContext;





public class LerArquivoCorpus {
	
	
	
	
	public LerArquivoCorpus(){
		
	}
	
	public ArrayList<ArrayList<String>> lerArquivo(){
		
		ArrayList<ArrayList<String>> listaArtigos = new ArrayList<ArrayList<String>>();
		
		for(int i=1; i<52;i++) {
		
			String path = (FacesContext.getCurrentInstance()
			           .getExternalContext()).getRealPath("/resources/corpus/"+i+".txt");
			
			File file = new File(path);
			
			 ArrayList<String> artigo = new ArrayList<String>();
			// String[] abrev;
			try { 
				FileReader arq = new FileReader(file); 
				BufferedReader lerArq = new BufferedReader(arq); 
				
				String linha = lerArq.readLine(); // l� a primeira linha //
				
				//a vari�vel "linha" recebe o valor "null" quando o processo 
				// de repeti��o atingir o final do arquivo texto
				
				while (linha != null) { 
					
					artigo.add(linha.toLowerCase());
					linha = lerArq.readLine(); // l� da segunda at� a �ltima linha 
				
				} 
				arq.close(); 
			} 
			catch (IOException e) { 
				System.err.printf("Erro na abertura do arquivo corpus: %s.\n", e.getMessage());
			} 
			
			listaArtigos.add(artigo);
		
		}
		

		return listaArtigos;
		
		
	}

}
