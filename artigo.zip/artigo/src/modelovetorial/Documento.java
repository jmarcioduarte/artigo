package modelovetorial;

public class Documento {
	
	int doc;
	double cosseno;
	public Documento(int doc, double cosseno) {
		this.doc = doc;
		this.cosseno = cosseno;
	}
	public int getDoc() {
		return doc;
	}
	public void setDoc(int doc) {
		this.doc = doc;
	}
	public double getCosseno() {
		return cosseno;
	}
	public void setCosseno(double cosseno) {
		this.cosseno = cosseno;
	}
	
	

}
