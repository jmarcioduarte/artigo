                   
        function hideForms(){               	                   	    
                    	document.getElementById('formArquivo').style.display='none';
                    	document.getElementById('formRelatorio').style.display='none';
                    	document.getElementById('formPontuacao').style.display='none';                    
                   }
                   
                   function visibleFormLista(){               	   	               	   
	                   	document.getElementById('formArquivo').style.display='block';
	                   	document.getElementById('formRelatorio').style.display='none';
	                   	document.getElementById('formPontuacao').style.display='none';
	                   
	                   	
                  }
                  function visibleFormRelatorio(){               	   	               	   
	                   	document.getElementById('formArquivo').style.display='none';
	                   	document.getElementById('formRelatorio').style.display='block';
	                   	document.getElementById('formPontuacao').style.display='none';	                   	                   
                 }
                  
                 function visibleFormPontuacao(){               	   	               	   
	                   	document.getElementById('formArquivo').style.display='none';
	                   	document.getElementById('formRelatorio').style.display='none';
	                   	document.getElementById('formPontuacao').style.display='block';	                   	                   
               } 