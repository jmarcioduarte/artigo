 
       var y;           
                   function hidePanels(){
                
                	   if(y==1){
                    	 alert('yes');
                	// 	document.getElementById('formDadosRelevantes').style.display='none';
                  
                    	document.getElementById('formUpload').style.display='none';
                    	document.getElementById('formRevisaoConceitos').style.display='none';
                    	document.getElementById('formPFA').style.display='none';
                    	document.getElementById('formDiagnosticoEnfermagem').style.display='none';  
                    	document.getElementById('formIntervencaoEnfermagem').style.display='none';
                    	document.getElementById('formResultadoEsperado').style.display='none';
                    	document.getElementById('formRelatorio').style.display='none';
                     }
                    }
                     
                    
                    function visibleFormDadosRelevantes(){
                    	
                    	 document.getElementById('formDadosRelevantes').style.display='block';
                    	document.getElementById('formUpload').style.display='none';
                    	document.getElementById('formRevisaoConceitos').style.display='none';
                    	document.getElementById('formPFA').style.display='none';             
                    	document.getElementById('formDiagnosticoEnfermagem').style.display='none';
                    	document.getElementById('formIntervencaoEnfermagem').style.display='none';
                    	document.getElementById('formResultadoEsperado').style.display='none';
                    	document.getElementById('formRelatorio').style.display='none';
                    	y=1; 
                    
                   
                    }
                    
                    
                    function visibleFormUpload(){
                    	alert(y);
                    	//document.getElementById('formDadosRelevantes').style.display='none';
                    	document.getElementById('formUpload').style.display='block';
                    	document.getElementById('formRevisaoConceitos').style.display='none';
                    	document.getElementById('formPFA').style.display='none';                    	
                    	document.getElementById('formDiagnosticoEnfermagem').style.display='none';
                    	document.getElementById('formIntervencaoEnfermagem').style.display='none';
                    	document.getElementById('formResultadoEsperado').style.display='none';
                    	document.getElementById('formRelatorio').style.display='none';
                    
                    }
                 
                    function visibleFormRevisaoConceitos(){
                     if(y=='block'){
                    //	document.getElementById('formDadosRelevantes').style.display='none';
                    	document.getElementById('formUpload').style.display='none';
                    	document.getElementById('formRevisaoConceitos').style.display='none';
                    	document.getElementById('formPFA').style.display='none';                    	
                    	document.getElementById('formDiagnosticoEnfermagem').style.display='none';
                    	document.getElementById('formIntervencaoEnfermagem').style.display='none';
                    	document.getElementById('formResultadoEsperado').style.display='none';
                    	document.getElementById('formRelatorio').style.display='none';
                     }	
                    }
                    
                    function visibleFormPFA(){
                    	
                    //	document.getElementById('formDadosRelevantes').style.display='none';
                    	document.getElementById('formUpload').style.display='none';
                    	document.getElementById('formRevisaoConceitos').style.display='none';
                    	document.getElementById('formPFA').style.display='block';                    	
                    	document.getElementById('formDiagnosticoEnfermagem').style.display='none';
                    	document.getElementById('formIntervencaoEnfermagem').style.display='none';
                    	document.getElementById('formResultadoEsperado').style.display='none';
                    	document.getElementById('formRelatorio').style.display='none';
                    }
                                     
                    
                    function visibleFormDiagnosticoEnfermagem(){
                    	
                    //	document.getElementById('formDadosRelevantes').style.display='none';
                    	document.getElementById('formUpload').style.display='none';
                    	document.getElementById('formRevisaoConceitos').style.display='none';
                    	document.getElementById('formPFA').style.display='none';                    	
                    	document.getElementById('formDiagnosticoEnfermagem').style.display='block';
                    	document.getElementById('formIntervencaoEnfermagem').style.display='none';
                    	document.getElementById('formResultadoEsperado').style.display='none';
                    	document.getElementById('formRelatorio').style.display='none';
                    }
                    
                    function visibleFormIntervencaoEnfermagem(){
                    	
                    	//document.getElementById('formDadosRelevantes').style.display='none';
                    	document.getElementById('formUpload').style.display='none';
                    	document.getElementById('formRevisaoConceitos').style.display='none';
                    	document.getElementById('formPFA').style.display='none';                    	
                    	document.getElementById('formDiagnosticoEnfermagem').style.display='none';
                    	document.getElementById('formIntervencaoEnfermagem').style.display='block';
                    	document.getElementById('formResultadoEsperado').style.display='none';
                    	document.getElementById('formRelatorio').style.display='none';
                   
                    }
                    
                    function visibleFormResultadoEsperado(){
                    	
                    //	document.getElementById('formDadosRelevantes').style.display='none';
                    	document.getElementById('formUpload').style.display='none';
                    	document.getElementById('formRevisaoConceitos').style.display='none';
                    	document.getElementById('formPFA').style.display='none';                    	
                    	document.getElementById('formDiagnosticoEnfermagem').style.display='none';
                    	document.getElementById('formIntervencaoEnfermagem').style.display='none';
                    	document.getElementById('formResultadoEsperado').style.display='block';
                    	document.getElementById('formRelatorio').style.display='none';
                   
                    }
                    
                    function visibleFormRelatorio(){
                    	
                    //	document.getElementById('formDadosRelevantes').style.display='none';
                    	document.getElementById('formUpload').style.display='none';
                    	document.getElementById('formRevisaoConceitos').style.display='none';
                    	document.getElementById('formPFA').style.display='none';                  	
                    	document.getElementById('formDiagnosticoEnfermagem').style.display='none';
                    	document.getElementById('formIntervencaoEnfermagem').style.display='none';
                    	document.getElementById('formResultadoEsperado').style.display='none';
                    	document.getElementById('formRelatorio').style.display='block';
                    }
                    
                    
                    
                        
                   