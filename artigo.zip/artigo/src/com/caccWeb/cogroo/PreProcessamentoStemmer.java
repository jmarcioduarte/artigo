package com.caccWeb.cogroo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.TreeMap;

import org.apache.lucene.analysis.en.EnglishAnalyzer;
import org.tartarus.snowball.ext.PorterStemmer;

import opennlp.tools.tokenize.Tokenizer;
import opennlp.tools.tokenize.TokenizerME;
import opennlp.tools.tokenize.TokenizerModel;
import opennlp.tools.util.InvalidFormatException;





/**
 * PorterStemAnalyzer processes input
 * text by stemming English words to their roots.
 * This Analyzer also converts the input to lower case
 * and removes stop words.  A small set of default stop
 * words is defined in the STOP_WORDS
 * array, but a caller can specify an alternative set
 * of stop words by calling non-default constructor.
 */
public class PreProcessamentoStemmer  {  
	
	
	
	TreeMap<String, Double> termos;
	int qtdeTotalTermos;
	
	public PreProcessamentoStemmer(){
		
		
		
	}
   	
	public ArrayList<ArrayList<String>> tokenizer(ArrayList<ArrayList<String>> corpusList) throws FileNotFoundException, IOException {
		
		
		ArrayList<ArrayList<String>> listaArtigos = new ArrayList<ArrayList<String>>();
		
		String path =this.getClass().getResource("/").getPath();
		
		path = path.substring(0, path.length()-16)+"resources/model/en-token.bin";
		
		try (InputStream modelIn = new FileInputStream(path)) {
			  TokenizerModel model = null;
			try {
				model = new TokenizerModel(modelIn);
			} catch (InvalidFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			  Tokenizer tokenizer = new TokenizerME(model);
			  
			  
			  for(int i=0; i<corpusList.size(); i++) {
				  ArrayList<String> artigo = new ArrayList<String>();
				  for(int j=0; j<corpusList.get(i).size();j++) {
				  
					  String tokens[] = tokenizer.tokenize(corpusList.get(i).get(j));
					  String stringTemp = null;
				  		for(int k=0; k<tokens.length; k++)
				  			if (k==0)
				  				stringTemp = tokens[k];
				  			else
				  				stringTemp = " "+stringTemp+" "+tokens[k]+" ";
				  		
				  		artigo.add(stringTemp);
				  }
				  listaArtigos.add(artigo);
				  
			}
		
			
		}
		
		
		return  listaArtigos;
		
	}
	
	public ArrayList<ArrayList<String>>  removeStopWords(ArrayList<ArrayList<String>> listaArtigosTokens){
		
		ArrayList<String>  stopWords = new ArrayList<String> ();
		
		ArrayList<ArrayList<String>> lArtigosRemovedSW = new ArrayList<ArrayList<String>>();
		
		Iterator iter = EnglishAnalyzer.getDefaultStopSet().iterator();
		
		while(iter.hasNext()) {
		    char[] stopWord = (char[]) iter.next();
		    stopWords.add(new String (stopWord));
		}
		
		
		
	  //  TokenStream tokenStream = new StandardTokenizer(new StringReader("Esta quase na hora de ir embora, o marcio viajou, e volta amanh�".trim()));
		for(int i=0; i<listaArtigosTokens.size(); i++){
			ArrayList<String> dadosTemp = new ArrayList<String>();
			for(int j=0; j<listaArtigosTokens.get(i).size(); j++){
				
				String temp = null;
				temp = " "+listaArtigosTokens.get(i).get(j);
				for(int k=0; k<stopWords.size();k++)
					temp = temp.replaceAll(" " + stopWords.get(k) + " ", " ");
			  	
				dadosTemp.add(temp);
			}
			lArtigosRemovedSW.add(dadosTemp);
		}
		
		//System.out.println(lArtigosRemovedSW.size());
		
		/*for (int i=0; i<lArtigosRemovedSW.size();i++) {
			System.out.println("\nArtigo  "+(i+1));
			
			for(int j=0; j<lArtigosRemovedSW.get(i).size(); j++) {
				
				System.out.println("sem stopwords "+ lArtigosRemovedSW.get(i).get(j));
			}	
			
			
		}	*/
		
		
		return lArtigosRemovedSW;
		
	}	
	

	public ArrayList<ArrayList<String>> tokenizerFinal(ArrayList<ArrayList<String>> listaArtigosSemSW) throws FileNotFoundException, IOException {
		
		
		ArrayList<ArrayList<String>> listaArtigos = new ArrayList<ArrayList<String>>();
		
		String path =this.getClass().getResource("/").getPath();
		
		path = path.substring(0, path.length()-16)+"resources/model/en-token.bin";
		
		try (InputStream modelIn = new FileInputStream(path)) {
			  TokenizerModel model = null;
			try {
				model = new TokenizerModel(modelIn);
			} catch (InvalidFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			  Tokenizer tokenizer = new TokenizerME(model);
			  
			  
			  for(int i=0; i<listaArtigosSemSW.size(); i++) {
				  ArrayList<String> artigo = new ArrayList<String>();
				  for(int j=0; j<listaArtigosSemSW.get(i).size();j++) {
				  
					  String tokens[] = tokenizer.tokenize(listaArtigosSemSW.get(i).get(j));
					
				  		for(int k=0; k<tokens.length; k++)
				  			if(tokens[k].equals("null")==false && tokens[k].equals(",")==false && tokens[k].equals(".")==false )
				  				artigo.add(tokens[k]);
				  			
				  		
				  		
				  }
				  listaArtigos.add(artigo);
				  
			}
		
			
		}
		
		/*for (int i=0; i<listaArtigos.size();i++) {
			System.out.println("\nArtigo  "+(i+1));
			if(i==0)
				for(int j=0; j<listaArtigos.get(i).size(); j++) {
			
					System.out.println("tokens "+ listaArtigos.get(i).get(j));
				}	
		
		
		}	*/
		
		
		return  listaArtigos;
		
	}
	
	
	
	public ArrayList<ArrayList<String>>  stemmer(ArrayList<ArrayList<String>> listaArtigos){
		
		ArrayList<ArrayList<String>> listaArtigosStem = new ArrayList<ArrayList<String>>();
		termos = new TreeMap<String, Double>();
		 
		  PorterStemmer stem = new PorterStemmer();
		  this.qtdeTotalTermos = 0;
		  for(int i=0;i< listaArtigos.size();i++){
			  
			  ArrayList<String> artigosStem = new ArrayList<String>();
			  for(int j=0; j<listaArtigos.get(i).size(); j++){
		
				  stem.setCurrent(listaArtigos.get(i).get(j));
				  stem.stem();
				  artigosStem.add(stem.getCurrent());
				  termos.put(stem.getCurrent(), 0.0);
				  this.qtdeTotalTermos = this.qtdeTotalTermos + 1;
			  }
			  listaArtigosStem.add(artigosStem);
		  }	
/*
		  for (int i=0; i<listaArtigosStem.size();i++) {
				System.out.println("\nArtigo  "+(i+1));
				if(i==0)
					for(int j=0; j<listaArtigosStem.get(i).size(); j++) {
				
						System.out.println("tokens "+ listaArtigosStem.get(i).get(j));
					}
			}	
		  */
		  
		  return listaArtigosStem;
	}

	public TreeMap<String, Double> getTermos() {
		return termos;
	}

	public void setTermos(TreeMap<String, Double> termos) {
		this.termos = termos;
	}

	public int getQtdeTotalTermos() {
		return qtdeTotalTermos;
	}

	public void setQtdeTotalTermos(int qtdeTotalTermos) {
		this.qtdeTotalTermos = qtdeTotalTermos;
	}
	
   
}  
  
