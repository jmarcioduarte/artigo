                   
               

				function hidePanels(){  
                	   
                		document.getElementById('panelEntrada').style.display='block'; 
                	   	document.getElementById('formFormulaDR').style.display='none'; 
                	   	document.getElementById('formFormulaConceito').style.display='none'; 
                	   	document.getElementById('formFormulaPFA').style.display='none'; 
                		document.getElementById('formFormulaIF').style.display='none'; 
                		document.getElementById('formFormulaDE').style.display='none'; 
                		document.getElementById('formFormulaRE').style.display='none'; 
                		document.getElementById('formFormulaIE').style.display='none';     					
                	  
                    	
                    	document.getElementById('formRevConceitual').style.display='none';
                    	document.getElementById('formPFA').style.display='none';
                    	                    		
                    	document.getElementById('formRE').style.display='none';
                    	document.getElementById('formIE').style.display='none';
                    	document.getElementById('formFileName').style.display='none';                    	                    	
                    	document.getElementById('formDiagAtivExerc').style.display='none';
                    	document.getElementById('formDiagNutMetab').style.display='none';
                    	document.getElementById('formDiagCogPercep').style.display='none';
                    	document.getElementById('formDiagSonoRep').style.display='none';
                    	document.getElementById('formDiagPercepCtrlSaude').style.display='none';
                    	document.getElementById('formDiagEliminacoes').style.display='none';
                    	document.getElementById('formDiagAutoPercepAutoConceito').style.display='none';
                    	document.getElementById('formDiagSexReprod').style.display='none';
                    	document.getElementById('formDiagPapelRel').style.display='none';
                    	document.getElementById('formDiagEnfrentEstresse').style.display='none';
                    	document.getElementById('formDiagValorCrenca').style.display='none';                    	                   	
                       	document.getElementById('formPFAEscolhido').style.display='none';
                       	document.getElementById('formIdentificacao').style.display='none';
                       	document.getElementById('formAntecedentesPF').style.display='none';
                       	
                       	document.getElementById('formHistoriaAtual').style.display='none';
                       	document.getElementById('formExameFisico').style.display='none';
                       	
                       	
                       	
                       	
                   }
                   
                   function visiblePanelPFAEscolhido(){ 
                	   	document.getElementById('panelEntrada').style.display='none';
               	   		document.getElementById('formFormulaDR').style.display='none'; 
               	   		document.getElementById('formFormulaConceito').style.display='none';
               	   		document.getElementById('formFormulaPFA').style.display='none'; 
               	   		document.getElementById('formFormulaIF').style.display='none'; 
               	   		document.getElementById('formFormulaDE').style.display='none'; 
               	   		document.getElementById('formFormulaRE').style.display='none'; 
               	   		document.getElementById('formFormulaIE').style.display='none'; 
	               	  
	                   	document.getElementById('formRevConceitual').style.display='none';
	                   	document.getElementById('formPFA').style.display='none';
	                   	document.getElementById('formRE').style.display='none';
	                   	document.getElementById('formIE').style.display='none';
	                   	document.getElementById('formFileName').style.display='none';                   	     
	                   	document.getElementById('formDiagAtivExerc').style.display='none';
	                   	document.getElementById('formDiagNutMetab').style.display='none';
	                   	document.getElementById('formDiagCogPercep').style.display='none';
	                   	document.getElementById('formDiagSonoRep').style.display='none';
	                   	document.getElementById('formDiagPercepCtrlSaude').style.display='none';
	                   	document.getElementById('formDiagEliminacoes').style.display='none';
	                   	document.getElementById('formDiagAutoPercepAutoConceito').style.display='none';
	                   	document.getElementById('formDiagSexReprod').style.display='none';
	                   	document.getElementById('formDiagPapelRel').style.display='none';
	                   	document.getElementById('formDiagEnfrentEstresse').style.display='none';
	                   	document.getElementById('formDiagValorCrenca').style.display='none';                    	                 
	                   	document.getElementById('formPFAEscolhido').style.display='block';
	                   	document.getElementById('formIdentificacao').style.display='none';
                       	document.getElementById('formAntecedentesPF').style.display='none';
                       	
                       	document.getElementById('formHistoriaAtual').style.display='none';
                       	document.getElementById('formExameFisico').style.display='none';
                       	
                       	
	                   	
                  }
                   function radioPFA(valor){
                	   if(valor=="a")               		   
                		   visiblePanelNutMetab();               	    
                	   if(valor=="b")
                		   visiblePanelAtivExerc();
                	   if(valor=="c")                		   
                		   visiblePanelCognitPercep();
                	   if(valor=="d")
                		   visiblePanelSonoRep();
                	   if(valor=="e")
                		   visiblePanelPercepCtrlSaude();
                	   if(valor=="f")
                		   visiblePanelElim();
                	   if(valor=="g")
                		   visiblePanelAutoPercep();
                	   if(valor=="h")
                		   visiblePanelSexReprod();
                	   if(valor=="i")
                		   visiblePanelPapelRel();
                	   if(valor=="j")
                		   visiblePanelEnfTolEstresse();
                	   if(valor=="k")
                		   visiblePanelValorCrenca();                	   
                   }
                   
                   function visiblePanelNutMetab(){
                	    document.getElementById('panelEntrada').style.display='none';
               	   		document.getElementById('formFormulaDR').style.display='none';
               	   		document.getElementById('formFormulaConceito').style.display='none';
               	   		document.getElementById('formFormulaPFA').style.display='none'; 
               	   		document.getElementById('formFormulaIF').style.display='none'; 
               	   		document.getElementById('formFormulaDE').style.display='none'; 
               	   		document.getElementById('formFormulaRE').style.display='none'; 
               	   		document.getElementById('formFormulaIE').style.display='none'; 
	                   	
	                   	document.getElementById('formRevConceitual').style.display='none';
	                   	document.getElementById('formPFA').style.display='none';
	                   	document.getElementById('formRE').style.display='none';
	                   	document.getElementById('formIE').style.display='none';
	                   	document.getElementById('formFileName').style.display='none';	                      
	                   	document.getElementById('formDiagNutMetab').style.display='block';	
	                   	document.getElementById('formDiagAtivExerc').style.display='none';
	                   	document.getElementById('formDiagCogPercep').style.display='none';
	                   	document.getElementById('formDiagSonoRep').style.display='none';
	                   	document.getElementById('formDiagPercepCtrlSaude').style.display='none';
	                   	document.getElementById('formDiagEliminacoes').style.display='none';
	                   	document.getElementById('formDiagAutoPercepAutoConceito').style.display='none';
	                   	document.getElementById('formDiagSexReprod').style.display='none';
                    	document.getElementById('formDiagPapelRel').style.display='none';
                    	document.getElementById('formDiagEnfrentEstresse').style.display='none';
                    	document.getElementById('formDiagValorCrenca').style.display='none'; 
                    	document.getElementById('formIdentificacao').style.display='none';
                    	document.getElementById('formPFAEscolhido').style.display='none';
                       	document.getElementById('formAntecedentesPF').style.display='none';
                       	
                       	document.getElementById('formHistoriaAtual').style.display='none';
                       	document.getElementById('formExameFisico').style.display='none';
                       	
                       	
                   }
                       
                   function visiblePanelAtivExerc(){  
                	    document.getElementById('panelEntrada').style.display='none';
              	   		document.getElementById('formFormulaDR').style.display='none';
              	   		document.getElementById('formFormulaConceito').style.display='none';
              	   		document.getElementById('formFormulaPFA').style.display='none'; 
              	   		document.getElementById('formFormulaIF').style.display='none'; 
              	   		document.getElementById('formFormulaDE').style.display='none'; 
              	   		document.getElementById('formFormulaRE').style.display='none'; 
              	   		document.getElementById('formFormulaIE').style.display='none'; 
              	   		
	                   	document.getElementById('formRevConceitual').style.display='none';
	                   	document.getElementById('formPFA').style.display='none';
	                   	document.getElementById('formRE').style.display='none';
	                   	document.getElementById('formIE').style.display='none';
	                   	document.getElementById('formFileName').style.display='none';
	                   	     
	                   	document.getElementById('formDiagNutMetab').style.display='none';
	                   	document.getElementById('formDiagAtivExerc').style.display='block';	   
	                   	document.getElementById('formDiagCogPercep').style.display='none';
	                	document.getElementById('formDiagSonoRep').style.display='none';
	                	document.getElementById('formDiagPercepCtrlSaude').style.display='none';
	                	document.getElementById('formDiagEliminacoes').style.display='none';
	                	document.getElementById('formDiagAutoPercepAutoConceito').style.display='none';
	                	document.getElementById('formDiagSexReprod').style.display='none';
	                	document.getElementById('formDiagPapelRel').style.display='none';
	                	document.getElementById('formDiagEnfrentEstresse').style.display='none';
	                	document.getElementById('formDiagValorCrenca').style.display='none';
	                	document.getElementById('formPFAEscolhido').style.display='none';
	                	document.getElementById('formIdentificacao').style.display='none';
                       	document.getElementById('formAntecedentesPF').style.display='none';
                       	
                       	document.getElementById('formHistoriaAtual').style.display='none';
                       	document.getElementById('formExameFisico').style.display='none';
                       	
                       	
                 }
                  
                   
                   function visiblePanelCognitPercep(){
                	    document.getElementById('panelEntrada').style.display='none';
               	   		document.getElementById('formFormulaDR').style.display='none';
               	   		document.getElementById('formFormulaConceito').style.display='none';
               	   		document.getElementById('formFormulaPFA').style.display='none'; 
               	   		document.getElementById('formFormulaIF').style.display='none'; 
               	   		document.getElementById('formFormulaDE').style.display='none'; 
               	   		document.getElementById('formFormulaRE').style.display='none'; 
               	   		document.getElementById('formFormulaIE').style.display='none'; 
	                   
	                   
	                   	document.getElementById('formRevConceitual').style.display='none';
	                   	document.getElementById('formPFA').style.display='none';
	                   	document.getElementById('formRE').style.display='none';
	                   	document.getElementById('formIE').style.display='none';
	                   	document.getElementById('formFileName').style.display='none';
	                   	     
	                   	document.getElementById('formDiagNutMetab').style.display='none';
	                 	document.getElementById('formDiagAtivExerc').style.display='none';
	                 	document.getElementById('formDiagCogPercep').style.display='block';	 
	                	document.getElementById('formDiagSonoRep').style.display='none';
                    	document.getElementById('formDiagPercepCtrlSaude').style.display='none';
                    	document.getElementById('formDiagEliminacoes').style.display='none';
                    	document.getElementById('formDiagAutoPercepAutoConceito').style.display='none';
                    	document.getElementById('formDiagSexReprod').style.display='none';
                    	document.getElementById('formDiagPapelRel').style.display='none';
                    	document.getElementById('formDiagEnfrentEstresse').style.display='none';
                    	document.getElementById('formDiagValorCrenca').style.display='none';
                    	document.getElementById('formPFAEscolhido').style.display='none';
                    	document.getElementById('formIdentificacao').style.display='none';
                       	document.getElementById('formAntecedentesPF').style.display='none';
                       	
                       	document.getElementById('formHistoriaAtual').style.display='none';
                       	document.getElementById('formExameFisico').style.display='none';
                       	
                       	
                   }
                   
                  
                   function visiblePanelSonoRep(){  
                	    document.getElementById('panelEntrada').style.display='none';
               	   		document.getElementById('formFormulaDR').style.display='none';
	               	   	document.getElementById('formFormulaConceito').style.display='none';
	           	   		document.getElementById('formFormulaPFA').style.display='none'; 
	           	   		document.getElementById('formFormulaIF').style.display='none'; 
	           	   		document.getElementById('formFormulaDE').style.display='none'; 
	           	   		document.getElementById('formFormulaRE').style.display='none'; 
	           	   		document.getElementById('formFormulaIE').style.display='none'; 
	           	   
	                   	document.getElementById('formRevConceitual').style.display='none';
	                   	document.getElementById('formPFA').style.display='none';
	                   	document.getElementById('formRE').style.display='none';
	                   	document.getElementById('formIE').style.display='none';
	                   	document.getElementById('formFileName').style.display='none';
	                   	     
	                  	document.getElementById('formDiagNutMetab').style.display='none';
	                  	document.getElementById('formDiagAtivExerc').style.display='none';
	                   	document.getElementById('formDiagCogPercep').style.display='none';
	                   	document.getElementById('formDiagSonoRep').style.display='block';	
                    	document.getElementById('formDiagPercepCtrlSaude').style.display='none';
                    	document.getElementById('formDiagEliminacoes').style.display='none';
                    	document.getElementById('formDiagAutoPercepAutoConceito').style.display='none';
                    	document.getElementById('formDiagSexReprod').style.display='none';
                    	document.getElementById('formDiagPapelRel').style.display='none';
                    	document.getElementById('formDiagEnfrentEstresse').style.display='none';
                    	document.getElementById('formDiagValorCrenca').style.display='none';
                    	document.getElementById('formPFAEscolhido').style.display='none';
                    	document.getElementById('formIdentificacao').style.display='none';
                       	document.getElementById('formAntecedentesPF').style.display='none';
                       	
                       	document.getElementById('formHistoriaAtual').style.display='none';
                       	document.getElementById('formExameFisico').style.display='none';
                       	
                       	
                   }
                                  																																															
					function visiblePanelPercepCtrlSaude(){
						document.getElementById('panelEntrada').style.display='none';
                	   	document.getElementById('formFormulaDR').style.display='none';
                	   	document.getElementById('formFormulaConceito').style.display='none';
               	   		document.getElementById('formFormulaPFA').style.display='none'; 
               	   		document.getElementById('formFormulaIF').style.display='none'; 
               	   		document.getElementById('formFormulaDE').style.display='none'; 
               	   		document.getElementById('formFormulaRE').style.display='none'; 
               	   		document.getElementById('formFormulaIE').style.display='none'; 
						
	                   	document.getElementById('formRevConceitual').style.display='none';
	                   	document.getElementById('formPFA').style.display='none';
	                   	document.getElementById('formRE').style.display='none';
	                   	document.getElementById('formIE').style.display='none';
	                   	document.getElementById('formFileName').style.display='none';
	                   	     
	                   	document.getElementById('formDiagNutMetab').style.display='none';
	                  	document.getElementById('formDiagAtivExerc').style.display='none';
	                   	document.getElementById('formDiagCogPercep').style.display='none';
	                   	document.getElementById('formDiagSonoRep').style.display='none';
	                   	document.getElementById('formDiagPercepCtrlSaude').style.display='block';
                    	document.getElementById('formDiagEliminacoes').style.display='none';
                    	document.getElementById('formDiagAutoPercepAutoConceito').style.display='none';
                    	document.getElementById('formDiagSexReprod').style.display='none';
                    	document.getElementById('formDiagPapelRel').style.display='none';
                    	document.getElementById('formDiagEnfrentEstresse').style.display='none';
                    	document.getElementById('formDiagValorCrenca').style.display='none';
                    	document.getElementById('formPFAEscolhido').style.display='none';
                    	document.getElementById('formIdentificacao').style.display='none';
                       	document.getElementById('formAntecedentesPF').style.display='none';
                       	
                       	document.getElementById('formHistoriaAtual').style.display='none';
                       	document.getElementById('formExameFisico').style.display='none';
                       	
                       	
	                		                			                			                	
					}
                                      
                   function visiblePanelElim(){  
                	    document.getElementById('panelEntrada').style.display='none';
               	   		document.getElementById('formFormulaDR').style.display='none';
	               	   	document.getElementById('formFormulaConceito').style.display='none';
	           	   		document.getElementById('formFormulaPFA').style.display='none'; 
	           	   		document.getElementById('formFormulaIF').style.display='none'; 
	           	   		document.getElementById('formFormulaDE').style.display='none'; 
	           	   		document.getElementById('formFormulaRE').style.display='none'; 
	           	   		document.getElementById('formFormulaIE').style.display='none'; 
	                   	
	                   	document.getElementById('formRevConceitual').style.display='none';
	                   	document.getElementById('formPFA').style.display='none';
	                   	document.getElementById('formRE').style.display='none';
	                   	document.getElementById('formIE').style.display='none';
	                   	document.getElementById('formFileName').style.display='none';
	                   	     
	                	document.getElementById('formDiagNutMetab').style.display='none';
	                  	document.getElementById('formDiagAtivExerc').style.display='none';
	                   	document.getElementById('formDiagCogPercep').style.display='none';
	                   	document.getElementById('formDiagSonoRep').style.display='none';
                    	document.getElementById('formDiagPercepCtrlSaude').style.display='none';
                    	document.getElementById('formDiagEliminacoes').style.display='block';	
                    	document.getElementById('formDiagAutoPercepAutoConceito').style.display='none';
                    	document.getElementById('formDiagSexReprod').style.display='none';
                    	document.getElementById('formDiagPapelRel').style.display='none';
                    	document.getElementById('formDiagEnfrentEstresse').style.display='none';
                    	document.getElementById('formDiagValorCrenca').style.display='none';
                    	document.getElementById('formPFAEscolhido').style.display='none';
                    	document.getElementById('formIdentificacao').style.display='none';
                       	document.getElementById('formAntecedentesPF').style.display='none';
                       	
                       	document.getElementById('formHistoriaAtual').style.display='none';
                       	document.getElementById('formExameFisico').style.display='none';
                       	
                       	
	                	                			                		                	              		
                   }
                                      
                   function visiblePanelAutoPercep(){
                	    document.getElementById('panelEntrada').style.display='none';
               	   		document.getElementById('formFormulaDR').style.display='none'; 
	               	   	document.getElementById('formFormulaConceito').style.display='none';
	           	   		document.getElementById('formFormulaPFA').style.display='none'; 
	           	   		document.getElementById('formFormulaIF').style.display='none'; 
	           	   		document.getElementById('formFormulaDE').style.display='none'; 
	           	   		document.getElementById('formFormulaRE').style.display='none'; 
	           	   		document.getElementById('formFormulaIE').style.display='none'; 
	                   	
	                   	document.getElementById('formRevConceitual').style.display='none';
	                   	document.getElementById('formPFA').style.display='none';
	                   	document.getElementById('formRE').style.display='none';
	                   	document.getElementById('formIE').style.display='none';
	                   	document.getElementById('formFileName').style.display='none';
	                   	     
	                	document.getElementById('formDiagNutMetab').style.display='none';
	                  	document.getElementById('formDiagAtivExerc').style.display='none';
	                   	document.getElementById('formDiagCogPercep').style.display='none';
	                   	document.getElementById('formDiagSonoRep').style.display='none';
                    	document.getElementById('formDiagPercepCtrlSaude').style.display='none';
                    	document.getElementById('formDiagEliminacoes').style.display='none';
                    	document.getElementById('formDiagAutoPercepAutoConceito').style.display='block';
                    	document.getElementById('formDiagSexReprod').style.display='none';
                    	document.getElementById('formDiagPapelRel').style.display='none';
                    	document.getElementById('formDiagEnfrentEstresse').style.display='none';
                    	document.getElementById('formDiagValorCrenca').style.display='none';
                    	document.getElementById('formPFAEscolhido').style.display='none';
                    	document.getElementById('formIdentificacao').style.display='none';
                       	document.getElementById('formAntecedentesPF').style.display='none';
                       	
                       	document.getElementById('formHistoriaAtual').style.display='none';
                       	document.getElementById('formExameFisico').style.display='none';
                       	
                       	
	                		                			                	                	              		
                   }
                   
                   function visiblePanelSexReprod(){
                	    document.getElementById('panelEntrada').style.display='none';
               	   		document.getElementById('formFormulaDR').style.display='none';
	               	   	document.getElementById('formFormulaConceito').style.display='none';
	           	   		document.getElementById('formFormulaPFA').style.display='none'; 
	           	   		document.getElementById('formFormulaIF').style.display='none'; 
	           	   		document.getElementById('formFormulaDE').style.display='none'; 
	           	   		document.getElementById('formFormulaRE').style.display='none'; 
	           	   		document.getElementById('formFormulaIE').style.display='none'; 
	                   	
	                   	document.getElementById('formRevConceitual').style.display='none';
	                   	document.getElementById('formPFA').style.display='none';
	                   	document.getElementById('formRE').style.display='none';
	                   	document.getElementById('formIE').style.display='none';
	                   	document.getElementById('formFileName').style.display='none';
	                   	     
	                	document.getElementById('formDiagNutMetab').style.display='none';
	                  	document.getElementById('formDiagAtivExerc').style.display='none';
	                   	document.getElementById('formDiagCogPercep').style.display='none';
	                   	document.getElementById('formDiagSonoRep').style.display='none';
                    	document.getElementById('formDiagPercepCtrlSaude').style.display='none';
                    	document.getElementById('formDiagEliminacoes').style.display='none';
                    	document.getElementById('formDiagAutoPercepAutoConceito').style.display='none';
                    	document.getElementById('formDiagSexReprod').style.display='block';	
                    	document.getElementById('formDiagPapelRel').style.display='none';
                    	document.getElementById('formDiagEnfrentEstresse').style.display='none';
                    	document.getElementById('formDiagValorCrenca').style.display='none';
                    	document.getElementById('formPFAEscolhido').style.display='none';
                    	document.getElementById('formIdentificacao').style.display='none';
                       	document.getElementById('formAntecedentesPF').style.display='none';
                       	
                       	document.getElementById('formHistoriaAtual').style.display='none';
                       	document.getElementById('formExameFisico').style.display='none';
                       	
                       	
	                	                			                			                	              		
                  }
                   
                   function visiblePanelPapelRel(){
                	    document.getElementById('panelEntrada').style.display='none';
               	   		document.getElementById('formFormulaDR').style.display='none';
	               	   	document.getElementById('formFormulaConceito').style.display='none';
	           	   		document.getElementById('formFormulaPFA').style.display='none'; 
	           	   		document.getElementById('formFormulaIF').style.display='none'; 
	           	   		document.getElementById('formFormulaDE').style.display='none'; 
	           	   		document.getElementById('formFormulaRE').style.display='none'; 
	           	   		document.getElementById('formFormulaIE').style.display='none'; 
	                   	
	                   	document.getElementById('formRevConceitual').style.display='none';
	                   	document.getElementById('formRE').style.display='none';
	                   	document.getElementById('formIE').style.display='none';
	                   	document.getElementById('formFileName').style.display='none';
	                   	     
	                	document.getElementById('formDiagNutMetab').style.display='none';
	                  	document.getElementById('formDiagAtivExerc').style.display='none';
	                   	document.getElementById('formDiagCogPercep').style.display='none';
	                   	document.getElementById('formDiagSonoRep').style.display='none';
                    	document.getElementById('formDiagPercepCtrlSaude').style.display='none';
                    	document.getElementById('formDiagEliminacoes').style.display='none';
                    	document.getElementById('formDiagAutoPercepAutoConceito').style.display='none';
                    	document.getElementById('formDiagSexReprod').style.display='none';
                    	document.getElementById('formDiagPapelRel').style.display='block';
                    	document.getElementById('formDiagEnfrentEstresse').style.display='none';
                    	document.getElementById('formDiagValorCrenca').style.display='none';
                    	document.getElementById('formPFAEscolhido').style.display='none';
                    	document.getElementById('formIdentificacao').style.display='none';
                       	document.getElementById('formAntecedentesPF').style.display='none';
                       	
                       	document.getElementById('formHistoriaAtual').style.display='none';
                       	document.getElementById('formExameFisico').style.display='none';
                       	
                       	
	                		                			                		                	              		
                  }
                   
                   function visiblePanelEnfTolEstresse(){
                	    document.getElementById('panelEntrada').style.display='none';
               	   		document.getElementById('formFormulaDR').style.display='none';
	               	   	document.getElementById('formFormulaConceito').style.display='none';
	           	   		document.getElementById('formFormulaPFA').style.display='none'; 
	           	   		document.getElementById('formFormulaIF').style.display='none'; 
	           	   		document.getElementById('formFormulaDE').style.display='none'; 
	           	   		document.getElementById('formFormulaRE').style.display='none'; 
	           	   		document.getElementById('formFormulaIE').style.display='none'; 
	                   	
	                   	document.getElementById('formRevConceitual').style.display='none';
	                   	document.getElementById('formPFA').style.display='none';
	                   	document.getElementById('formRE').style.display='none';
	                   	document.getElementById('formIE').style.display='none';
	                   	document.getElementById('formFileName').style.display='none';
	                   	     
	                	document.getElementById('formDiagNutMetab').style.display='none';
	                  	document.getElementById('formDiagAtivExerc').style.display='none';
	                   	document.getElementById('formDiagCogPercep').style.display='none';
	                   	document.getElementById('formDiagSonoRep').style.display='none';
                    	document.getElementById('formDiagPercepCtrlSaude').style.display='none';
                    	document.getElementById('formDiagEliminacoes').style.display='none';
                    	document.getElementById('formDiagAutoPercepAutoConceito').style.display='none';
                    	document.getElementById('formDiagSexReprod').style.display='none';
                    	document.getElementById('formDiagPapelRel').style.display='none';
                    	document.getElementById('formDiagEnfrentEstresse').style.display='block';
                    	document.getElementById('formDiagValorCrenca').style.display='none';
                    	document.getElementById('formPFAEscolhido').style.display='none';
                    	document.getElementById('formIdentificacao').style.display='none';
                       	document.getElementById('formAntecedentesPF').style.display='none';
                       	
                       	document.getElementById('formHistoriaAtual').style.display='none';
                       	document.getElementById('formExameFisico').style.display='none';
                       	
                       	
	                		                			                		                	              		
                   }
                   
                   function visiblePanelValorCrenca(){
                	    document.getElementById('panelEntrada').style.display='none';
               	   		document.getElementById('formFormulaDR').style.display='none';
	               	   	document.getElementById('formFormulaConceito').style.display='none';
	           	   		document.getElementById('formFormulaPFA').style.display='none'; 
	           	   		document.getElementById('formFormulaIF').style.display='none'; 
	           	   		document.getElementById('formFormulaDE').style.display='none'; 
	           	   		document.getElementById('formFormulaRE').style.display='none'; 
	           	   		document.getElementById('formFormulaIE').style.display='none'; 
	                   	
	                   	document.getElementById('formRevConceitual').style.display='none';
	                   	document.getElementById('formPFA').style.display='none';
	                   	document.getElementById('formRE').style.display='none';
	                   	document.getElementById('formIE').style.display='none';
	                   	document.getElementById('formFileName').style.display='none';
	                   	     
	                	document.getElementById('formDiagNutMetab').style.display='none';
	                  	document.getElementById('formDiagAtivExerc').style.display='none';
	                   	document.getElementById('formDiagCogPercep').style.display='none';
	                   	document.getElementById('formDiagSonoRep').style.display='none';
                    	document.getElementById('formDiagPercepCtrlSaude').style.display='none';
                    	document.getElementById('formDiagEliminacoes').style.display='none';
                    	document.getElementById('formDiagAutoPercepAutoConceito').style.display='none';
                    	document.getElementById('formDiagSexReprod').style.display='none';
                    	document.getElementById('formDiagPapelRel').style.display='none';
                    	document.getElementById('formDiagEnfrentEstresse').style.display='none';
                    	document.getElementById('formDiagValorCrenca').style.display='block';
                    	document.getElementById('formPFAEscolhido').style.display='none';
                    	document.getElementById('formIdentificacao').style.display='none';
                       	document.getElementById('formAntecedentesPF').style.display='none';
                       	
                       	document.getElementById('formHistoriaAtual').style.display='none';
                       	document.getElementById('formExameFisico').style.display='none';
                       	
                       	
                  }
                                                        					
                   function visiblePanelFormulaDE(){  
                	    document.getElementById('panelEntrada').style.display='none';
	                   	document.getElementById('formFormulaDR').style.display='none';
	                   	document.getElementById('formFormulaConceito').style.display='none';
               	   		document.getElementById('formFormulaPFA').style.display='none'; 
               	   		document.getElementById('formFormulaIF').style.display='none'; 
               	   		document.getElementById('formFormulaDE').style.display='none'; 
               	   		document.getElementById('formFormulaRE').style.display='none'; 
               	   		document.getElementById('formFormulaIE').style.display='none'; 
	                   	                   	
	                   	document.getElementById('formRevConceitual').style.display='none';
	                   	document.getElementById('formPFA').style.display='none';
	                   	document.getElementById('formRE').style.display='none';
	                   	document.getElementById('formIE').style.display='none';
	                   	document.getElementById('formFileName').style.display='none';
	                   	     
	                   	document.getElementById('formDiagAtivExerc').style.display='none';
	                   	document.getElementById('formDiagNutMetab').style.display='none';
	                   	document.getElementById('formDiagCogPercep').style.display='none';
	                   	document.getElementById('formDiagSonoRep').style.display='none';
	                   	document.getElementById('formDiagPercepCtrlSaude').style.display='none';
	                   	document.getElementById('formDiagEliminacoes').style.display='none';
	                   	document.getElementById('formDiagAutoPercepAutoConceito').style.display='none';
	                   	document.getElementById('formDiagSexReprod').style.display='none';
	                   	document.getElementById('formDiagPapelRel').style.display='none';
	                   	document.getElementById('formDiagEnfrentEstresse').style.display='none';
	                   	document.getElementById('formDiagValorCrenca').style.display='none';                    	
	                   	document.getElementById('formPFAEscolhido').style.display='none';
	                   	document.getElementById('formIdentificacao').style.display='none';
                       	document.getElementById('formAntecedentesPF').style.display='none';
                       	
                       	document.getElementById('formHistoriaAtual').style.display='none';
                       	document.getElementById('formExameFisico').style.display='none';
                       	
                       	
                   }
                   
                  function visiblePanelDiagnostico(){
                	  	document.getElementById('panelEntrada').style.display='none';
              	   		document.getElementById('formFormulaDR').style.display='none';
	              	   	document.getElementById('formFormulaConceito').style.display='none';
	           	   		document.getElementById('formFormulaPFA').style.display='none'; 
	           	   		document.getElementById('formFormulaIF').style.display='none'; 
	           	   		document.getElementById('formFormulaDE').style.display='none'; 
	           	   		document.getElementById('formFormulaRE').style.display='none'; 
	           	   		document.getElementById('formFormulaIE').style.display='none'; 
                    	
                    	document.getElementById('formRevConceitual').style.display='none';
                    	document.getElementById('formPFA').style.display='none';
                    	document.getElementById('formRE').style.display='none';
                    	document.getElementById('formIE').style.display='none';
                    	document.getElementById('formFileName').style.display='none';
                    	document.getElementById('formPFAEscolhido').style.display='none';
                    	document.getElementById('formIdentificacao').style.display='none';
                       	document.getElementById('formAntecedentesPF').style.display='none';
                       	
                       	document.getElementById('formHistoriaAtual').style.display='none';
                       	document.getElementById('formExameFisico').style.display='none';
                       	
                       	
                    	     
                    	
                    	if(nutMetabolico==1)
                			document.getElementById('formDiagNutMetab').style.display='block';
                    	else
                			document.getElementById('formDiagNutMetab').style.display='none';
                    	
                    	if(ativExercicio==1)
                			document.getElementById('formDiagAtivExerc').style.display='block';
                		else
                			document.getElementById('formDiagAtivExerc').style.display='none';
                    	
                    	if(cogPercep==1)
                			document.getElementById('formDiagCogPercep').style.display='block';
                		else
                			document.getElementById('formDiagCogPercep').style.display='none';
                    	
                    	if(sonoRep==1)
                			document.getElementById('formDiagSonoRep').style.display='block';
                		else
                			document.getElementById('formDiagSonoRep').style.display='none';
                    	
                    	if(percepCtrlSaude==1)
                			document.getElementById('formDiagPercepCtrlSaude').style.display='block';
                		else
                			document.getElementById('formDiagPercepCtrlSaude').style.display='none';
                    	
                    	if(eliminacoes==1)
                			document.getElementById('formDiagEliminacoes').style.display='block';
                		else
                			document.getElementById('formDiagEliminacoes').style.display='none';
                    	
                    	if(autoPercepAutoConceito==1)
                			document.getElementById('formDiagAutoPercepAutoConceito').style.display='block';
                		else
                			document.getElementById('formDiagAutoPercepAutoConceito').style.display='none';
                    	
                    	if(sexReprod==1)
                			document.getElementById('formDiagSexReprod').style.display='block';
                		else
                			document.getElementById('formDiagSexReprod').style.display='none';
                    	
                    	if(papelRel==1)
                			document.getElementById('formDiagPapelRel').style.display='block';
                		else
                			document.getElementById('formDiagPapelRel').style.display='none';
                    	
                    	if(enfrentEstresse==1)
                			document.getElementById('formDiagEnfrentEstresse').style.display='block';
                		else
                			document.getElementById('formDiagEnfrentEstresse').style.display='none';
                    	
                    	if(valorCrenca==1)
                			document.getElementById('formDiagValorCrenca').style.display='block';
                		else
                			document.getElementById('formDiagValorCrenca').style.display='none';                    	                    	
                    }
                                                          
                    var nutMetabolico;
                    var ativExercicio;
                    var cogPercep;
                    var sonoRep;
                    var percepCtrlSaude;
                    var eliminacoes;
                    var autoPercepAutoConceito;
                    var sexReprod;
                    var papelRel;
                    var enfrentEstresse;
                    var valorCrenca;
                    
                    function setNutMetabolico(show){ 
                    	
                    	if(show)
                    		nutMetabolico=1;
                    	else	
                    		nutMetabolico=0;
                    } 
                     
                    function setAtivExercicio(show){ 
                    	
                    	if(show)
                    		ativExercicio=1;
                    	else	
                    		ativExercicio=0;
                    }
                    
                    function setCogPercep(show){ 
                    	
                    	if(show)
                    		cogPercep=1;
                    	else	
                    		cogPercep=0;
                    }
                    
                    function setSonoRep(show){ 
                    	
                    	if(show)
                    		sonoRep=1;
                    	else	
                    		sonoRep=0;
                    }
                    
                    function setPercepCtrlSaude(show){ 
                    	
                    	if(show)
                    		percepCtrlSaude=1;
                    	else	
                    		percepCtrlSaude=0;
                    }
                    
                    function setEliminacoes(show){ 
                    	
                    	if(show)
                    		eliminacoes=1;
                    	else	
                    		eliminacoes=0;
                    }
                                    
                    function setAutoPercepAutoConceito(show){ 
                    	
                    	if(show)
                    		autoPercepAutoConceito=1;
                    	else	
                    		autoPercepAutoConceito=0;
                    }
                    
                    function setSexReprod(show){ 
                    	
                    	if(show)
                    		sexReprod=1;
                    	else	
                    		sexReprod=0;
                    }
                    
                    function setPapelRel(show){ 
                    	
                    	if(show)
                    		papelRel=1;
                    	else	
                    		papelRel=0;
                    }

                    function setEnfrentEstresse(show){ 
	
                    	if(show)
                    		enfrentEstresse=1;
                    	else	
                    		enfrentEstresse=0;
                    }

                    function setValorCrenca(show){ 
	
                    	if(show)
                    		valorCrenca=1;
                    	else	
                    		valorCrenca=0;
                    }
                                     
                    function visiblePanelFormulaDR(){ 
                    	document.getElementById('panelEntrada').style.display='none';
                    	document.getElementById('formFormulaDR').style.display='block';
                    	document.getElementById('formFormulaConceito').style.display='block';
               	   		document.getElementById('formFormulaPFA').style.display='block'; 
               	   		document.getElementById('formFormulaIF').style.display='block'; 
               	   		document.getElementById('formFormulaDE').style.display='block'; 
               	   		document.getElementById('formFormulaRE').style.display='block'; 
               	   		document.getElementById('formFormulaIE').style.display='block'; 
                    	                   	
                    	document.getElementById('formRevConceitual').style.display='none';
                    	document.getElementById('formPFA').style.display='none';
                    	document.getElementById('formRE').style.display='none';
                    	document.getElementById('formIE').style.display='none';
                    	document.getElementById('formFileName').style.display='none';
                    	     
                    	document.getElementById('formDiagAtivExerc').style.display='none';
                    	document.getElementById('formDiagNutMetab').style.display='none';
                    	document.getElementById('formDiagCogPercep').style.display='none';
                    	document.getElementById('formDiagSonoRep').style.display='none';
                    	document.getElementById('formDiagPercepCtrlSaude').style.display='none';
                    	document.getElementById('formDiagEliminacoes').style.display='none';
                    	document.getElementById('formDiagAutoPercepAutoConceito').style.display='none';
                    	document.getElementById('formDiagSexReprod').style.display='none';
                    	document.getElementById('formDiagPapelRel').style.display='none';
                    	document.getElementById('formDiagEnfrentEstresse').style.display='none';
                    	document.getElementById('formDiagValorCrenca').style.display='none';                    	                   	
                    	document.getElementById('formPFAEscolhido').style.display='none';
                    	document.getElementById('formIdentificacao').style.display='none';
                       	document.getElementById('formAntecedentesPF').style.display='none';
                       	
                       	document.getElementById('formHistoriaAtual').style.display='none';
                       	document.getElementById('formExameFisico').style.display='none';
                       	
                       	
                    }
                                        
                    
                                        
                    
                    
                    
                    
                    function visiblePanelRevisaoConceitos(){
                    	document.getElementById('panelEntrada').style.display='none';
                	   	document.getElementById('formFormulaDR').style.display='none';   
                	   	document.getElementById('formFormulaConceito').style.display='none';
               	   		document.getElementById('formFormulaPFA').style.display='none'; 
               	   		document.getElementById('formFormulaIF').style.display='none'; 
               	   		document.getElementById('formFormulaDE').style.display='none'; 
               	   		document.getElementById('formFormulaRE').style.display='none'; 
               	   		document.getElementById('formFormulaIE').style.display='none'; 
                    	                  	
                    	
                    	document.getElementById('formRevConceitual').style.display='block';
                    	document.getElementById('formPFA').style.display='none';
                    	;
                    	document.getElementById('formRE').style.display='none';
                    	document.getElementById('formIE').style.display='none';
                    	document.getElementById('formFileName').style.display='none';
                    	     
                    	document.getElementById('formDiagAtivExerc').style.display='none';
                    	document.getElementById('formDiagNutMetab').style.display='none';
                    	document.getElementById('formDiagCogPercep').style.display='none';
                    	document.getElementById('formDiagSonoRep').style.display='none';
                    	document.getElementById('formDiagPercepCtrlSaude').style.display='none';
                    	document.getElementById('formDiagEliminacoes').style.display='none';
                    	document.getElementById('formDiagAutoPercepAutoConceito').style.display='none';
                    	document.getElementById('formDiagSexReprod').style.display='none';
                    	document.getElementById('formDiagPapelRel').style.display='none';
                    	document.getElementById('formDiagEnfrentEstresse').style.display='none';
                    	document.getElementById('formDiagValorCrenca').style.display='none';                    	                    	
                    	document.getElementById('formPFAEscolhido').style.display='none';
                    	document.getElementById('formIdentificacao').style.display='none';
                       	document.getElementById('formAntecedentesPF').style.display='none';
                       	
                       	document.getElementById('formHistoriaAtual').style.display='none';
                       	document.getElementById('formExameFisico').style.display='none';
                       	
                       	
                    }
                    
                
                    function visiblePanelPFA(){
                    	document.getElementById('panelEntrada').style.display='none';
                	   	document.getElementById('formFormulaDR').style.display='none';   
                	   	document.getElementById('formFormulaConceito').style.display='none';
               	   		document.getElementById('formFormulaPFA').style.display='none'; 
               	   		document.getElementById('formFormulaIF').style.display='none'; 
               	   		document.getElementById('formFormulaDE').style.display='none'; 
               	   		document.getElementById('formFormulaRE').style.display='none'; 
               	   		document.getElementById('formFormulaIE').style.display='none'; 
                    	                 	
                    	
                    	document.getElementById('formRevConceitual').style.display='none';
                    	document.getElementById('formPFA').style.display='block';
                    	
                    	document.getElementById('formRE').style.display='none';
                    	document.getElementById('formIE').style.display='none';
                    	document.getElementById('formFileName').style.display='none';
                    	     
                    	document.getElementById('formDiagAtivExerc').style.display='none';
                    	document.getElementById('formDiagNutMetab').style.display='none';
                    	document.getElementById('formDiagCogPercep').style.display='none';
                    	document.getElementById('formDiagSonoRep').style.display='none';
                    	document.getElementById('formDiagPercepCtrlSaude').style.display='none';
                    	document.getElementById('formDiagEliminacoes').style.display='none';
                    	document.getElementById('formDiagAutoPercepAutoConceito').style.display='none';
                    	document.getElementById('formDiagSexReprod').style.display='none';
                    	document.getElementById('formDiagPapelRel').style.display='none';
                    	document.getElementById('formDiagEnfrentEstresse').style.display='none';
                    	document.getElementById('formDiagValorCrenca').style.display='none';                    	                   	
                    	document.getElementById('formPFAEscolhido').style.display='none';
                    	document.getElementById('formIdentificacao').style.display='none';
                       	document.getElementById('formAntecedentesPF').style.display='none';
                       	
                       	document.getElementById('formHistoriaAtual').style.display='none';
                       	document.getElementById('formExameFisico').style.display='none';
                       	
                       	
                    }
                                        
                  
                    
                    
                    function visiblePanelRE(){
                    	document.getElementById('panelEntrada').style.display='none';
                	   	document.getElementById('formFormulaDR').style.display='none';   
                	   	document.getElementById('formFormulaConceito').style.display='none';
               	   		document.getElementById('formFormulaPFA').style.display='none'; 
               	   		document.getElementById('formFormulaIF').style.display='none'; 
               	   		document.getElementById('formFormulaDE').style.display='none'; 
               	   		document.getElementById('formFormulaRE').style.display='none'; 
               	   		document.getElementById('formFormulaIE').style.display='none'; 
                    	            	
                    	document.getElementById('formRevConceitual').style.display='none';
                    	document.getElementById('formPFA').style.display='none';
                    	document.getElementById('formRE').style.display='block';                   
                    	document.getElementById('formIE').style.display='none';
                    	document.getElementById('formFileName').style.display='none';
                    	     
                    	document.getElementById('formDiagAtivExerc').style.display='none';
                    	document.getElementById('formDiagNutMetab').style.display='none';
                    	document.getElementById('formDiagCogPercep').style.display='none';
                    	document.getElementById('formDiagSonoRep').style.display='none';
                    	document.getElementById('formDiagPercepCtrlSaude').style.display='none';
                    	document.getElementById('formDiagEliminacoes').style.display='none';
                    	document.getElementById('formDiagAutoPercepAutoConceito').style.display='none';
                    	document.getElementById('formDiagSexReprod').style.display='none';
                    	document.getElementById('formDiagPapelRel').style.display='none';
                    	document.getElementById('formDiagEnfrentEstresse').style.display='none';
                    	document.getElementById('formDiagValorCrenca').style.display='none';                    	                    	
                    	document.getElementById('formPFAEscolhido').style.display='none';
                    	document.getElementById('formIdentificacao').style.display='none';
                       	document.getElementById('formAntecedentesPF').style.display='none';
                       	
                       	document.getElementById('formHistoriaAtual').style.display='none';
                       	document.getElementById('formExameFisico').style.display='none';
                       	
                       	
                    }
                    
                   
                    
                    function visiblePanelIE(){
                    	document.getElementById('panelEntrada').style.display='none';
                	   	document.getElementById('formFormulaDR').style.display='none';   
                	   	document.getElementById('formFormulaConceito').style.display='none';
               	   		document.getElementById('formFormulaPFA').style.display='none'; 
               	   		document.getElementById('formFormulaIF').style.display='none'; 
               	   		document.getElementById('formFormulaDE').style.display='none'; 
               	   		document.getElementById('formFormulaRE').style.display='none'; 
               	   		document.getElementById('formFormulaIE').style.display='none'; 
                    	                  	
                    	document.getElementById('formRevConceitual').style.display='none';
                    	document.getElementById('formPFA').style.display='none';
                    	document.getElementById('formRE').style.display='none';
                    	document.getElementById('formIE').style.display='block';
                    	document.getElementById('formFileName').style.display='none';
                    	     
                    	document.getElementById('formDiagAtivExerc').style.display='none';
                    	document.getElementById('formDiagNutMetab').style.display='none';
                    	document.getElementById('formDiagCogPercep').style.display='none';
                    	document.getElementById('formDiagSonoRep').style.display='none';
                    	document.getElementById('formDiagPercepCtrlSaude').style.display='none';
                    	document.getElementById('formDiagEliminacoes').style.display='none';
                    	document.getElementById('formDiagAutoPercepAutoConceito').style.display='none';
                    	document.getElementById('formDiagSexReprod').style.display='none';
                    	document.getElementById('formDiagPapelRel').style.display='none';
                    	document.getElementById('formDiagEnfrentEstresse').style.display='none';
                    	document.getElementById('formDiagValorCrenca').style.display='none';                    	                    	
                    	document.getElementById('formPFAEscolhido').style.display='none';
                    	document.getElementById('formIdentificacao').style.display='none';
                       	document.getElementById('formAntecedentesPF').style.display='none';
                       	
                       	document.getElementById('formHistoriaAtual').style.display='none';
                       	document.getElementById('formExameFisico').style.display='none';
                       	
                       	
                    }
                    
                    function visibleFormFileName(){
                    	
                    	document.getElementById('panelEntrada').style.display='none';
                	   	document.getElementById('formFormulaDR').style.display='none';    
                	   	document.getElementById('formFormulaConceito').style.display='none';
               	   		document.getElementById('formFormulaPFA').style.display='none'; 
               	   		document.getElementById('formFormulaIF').style.display='none'; 
               	   		document.getElementById('formFormulaDE').style.display='none'; 
               	   		document.getElementById('formFormulaRE').style.display='none'; 
               	   		document.getElementById('formFormulaIE').style.display='none'; 
                    	                    	
                    	document.getElementById('formRevConceitual').style.display='none';
                    	document.getElementById('formPFA').style.display='none';
                    	document.getElementById('formRE').style.display='none';
                    	document.getElementById('formIE').style.display='none';
                    	document.getElementById('formFileName').style.display='block';
                    	
                    	document.getElementById('formDiagAtivExerc').style.display='none';
                    	document.getElementById('formDiagNutMetab').style.display='none';
                    	document.getElementById('formDiagCogPercep').style.display='none';
                    	document.getElementById('formDiagSonoRep').style.display='none';
                    	document.getElementById('formDiagPercepCtrlSaude').style.display='none';
                    	document.getElementById('formDiagEliminacoes').style.display='none';
                    	document.getElementById('formDiagAutoPercepAutoConceito').style.display='none';
                    	document.getElementById('formDiagSexReprod').style.display='none';
                    	document.getElementById('formDiagPapelRel').style.display='none';
                    	document.getElementById('formDiagEnfrentEstresse').style.display='none';
                    	document.getElementById('formDiagValorCrenca').style.display='none';                    	                   	
                    	document.getElementById('formPFAEscolhido').style.display='none';
                    	document.getElementById('formIdentificacao').style.display='none';
                       	document.getElementById('formAntecedentesPF').style.display='none';
                       	
                       	document.getElementById('formHistoriaAtual').style.display='none';
                       	document.getElementById('formExameFisico').style.display='none';
                       	
                       	
                    }
                    
                   
                 
                    
                    function visiblePanelIdentificacao(){
                    	
                    	document.getElementById('panelEntrada').style.display='none';
                	   	document.getElementById('formFormulaDR').style.display='none';    
                	   	document.getElementById('formFormulaConceito').style.display='none';
               	   		document.getElementById('formFormulaPFA').style.display='none'; 
               	   		document.getElementById('formFormulaIF').style.display='none'; 
               	   		document.getElementById('formFormulaDE').style.display='none'; 
               	   		document.getElementById('formFormulaRE').style.display='none'; 
               	   		document.getElementById('formFormulaIE').style.display='none'; 
                    	                    	
                    	document.getElementById('formRevConceitual').style.display='none';
                    	document.getElementById('formPFA').style.display='none';
                    	document.getElementById('formRE').style.display='none';
                    	document.getElementById('formIE').style.display='none';
                    	document.getElementById('formFileName').style.display='none';
                    	
                    	document.getElementById('formDiagAtivExerc').style.display='none';
                    	document.getElementById('formDiagNutMetab').style.display='none';
                    	document.getElementById('formDiagCogPercep').style.display='none';
                    	document.getElementById('formDiagSonoRep').style.display='none';
                    	document.getElementById('formDiagPercepCtrlSaude').style.display='none';
                    	document.getElementById('formDiagEliminacoes').style.display='none';
                    	document.getElementById('formDiagAutoPercepAutoConceito').style.display='none';
                    	document.getElementById('formDiagSexReprod').style.display='none';
                    	document.getElementById('formDiagPapelRel').style.display='none';
                    	document.getElementById('formDiagEnfrentEstresse').style.display='none';
                    	document.getElementById('formDiagValorCrenca').style.display='none';                    	                   	
                    	document.getElementById('formPFAEscolhido').style.display='none';                
                    	document.getElementById('formIdentificacao').style.display='block';
                       	document.getElementById('formAntecedentesPF').style.display='none';
                       	
                       	document.getElementById('formHistoriaAtual').style.display='none';
                       	document.getElementById('formExameFisico').style.display='none';
                       	
                       	
                    }
                    
                    function visiblePanelAntecedentesPF(){
                    	
                    	document.getElementById('panelEntrada').style.display='none';
                	   	document.getElementById('formFormulaDR').style.display='none';    
                	   	document.getElementById('formFormulaConceito').style.display='none';
               	   		document.getElementById('formFormulaPFA').style.display='none'; 
               	   		document.getElementById('formFormulaIF').style.display='none'; 
               	   		document.getElementById('formFormulaDE').style.display='none'; 
               	   		document.getElementById('formFormulaRE').style.display='none'; 
               	   		document.getElementById('formFormulaIE').style.display='none'; 
                    	                    	
                    	document.getElementById('formRevConceitual').style.display='none';
                    	document.getElementById('formPFA').style.display='none';
                    	document.getElementById('formRE').style.display='none';
                    	document.getElementById('formIE').style.display='none';
                    	document.getElementById('formFileName').style.display='none';
                    	
                    	document.getElementById('formDiagAtivExerc').style.display='none';
                    	document.getElementById('formDiagNutMetab').style.display='none';
                    	document.getElementById('formDiagCogPercep').style.display='none';
                    	document.getElementById('formDiagSonoRep').style.display='none';
                    	document.getElementById('formDiagPercepCtrlSaude').style.display='none';
                    	document.getElementById('formDiagEliminacoes').style.display='none';
                    	document.getElementById('formDiagAutoPercepAutoConceito').style.display='none';
                    	document.getElementById('formDiagSexReprod').style.display='none';
                    	document.getElementById('formDiagPapelRel').style.display='none';
                    	document.getElementById('formDiagEnfrentEstresse').style.display='none';
                    	document.getElementById('formDiagValorCrenca').style.display='none';                    	                   	
                    	document.getElementById('formPFAEscolhido').style.display='none';
                    	document.getElementById('formIdentificacao').style.display='none';
                       	document.getElementById('formAntecedentesPF').style.display='block';
                       	
                       	document.getElementById('formHistoriaAtual').style.display='none';
                       	document.getElementById('formExameFisico').style.display='none';
                       	
                       
                    }
                    
                  
                    function visiblePanelHistoriaAtual(){
                    	
                    	document.getElementById('panelEntrada').style.display='none';
                	   	document.getElementById('formFormulaDR').style.display='none';    
                	   	document.getElementById('formFormulaConceito').style.display='none';
               	   		document.getElementById('formFormulaPFA').style.display='none'; 
               	   		document.getElementById('formFormulaIF').style.display='none'; 
               	   		document.getElementById('formFormulaDE').style.display='none'; 
               	   		document.getElementById('formFormulaRE').style.display='none'; 
               	   		document.getElementById('formFormulaIE').style.display='none'; 
                    	                    	
                    	document.getElementById('formRevConceitual').style.display='none';
                    	document.getElementById('formPFA').style.display='none';
                    	document.getElementById('formRE').style.display='none';
                    	document.getElementById('formIE').style.display='none';
                    	document.getElementById('formFileName').style.display='none';
                    
                    	document.getElementById('formDiagAtivExerc').style.display='none';
                    	document.getElementById('formDiagNutMetab').style.display='none';
                    	document.getElementById('formDiagCogPercep').style.display='none';
                    	document.getElementById('formDiagSonoRep').style.display='none';
                    	document.getElementById('formDiagPercepCtrlSaude').style.display='none';
                    	document.getElementById('formDiagEliminacoes').style.display='none';
                    	document.getElementById('formDiagAutoPercepAutoConceito').style.display='none';
                    	document.getElementById('formDiagSexReprod').style.display='none';
                    	document.getElementById('formDiagPapelRel').style.display='none';
                    	document.getElementById('formDiagEnfrentEstresse').style.display='none';
                    	document.getElementById('formDiagValorCrenca').style.display='none';                    	                   	
                    	document.getElementById('formPFAEscolhido').style.display='none';
                    	document.getElementById('formIdentificacao').style.display='none';
                       	document.getElementById('formAntecedentesPF').style.display='none';
                       	
                       	document.getElementById('formHistoriaAtual').style.display='block';
                       	document.getElementById('formExameFisico').style.display='none';
                       	
                       	
                       	
                    }
                    
                    function visiblePanelExameFisico(){
                    
                    	document.getElementById('panelEntrada').style.display='none';
                	   	document.getElementById('formFormulaDR').style.display='none';    
                	   	document.getElementById('formFormulaConceito').style.display='none';
               	   		document.getElementById('formFormulaPFA').style.display='none'; 
               	   		document.getElementById('formFormulaIF').style.display='none'; 
               	   		document.getElementById('formFormulaDE').style.display='none'; 
               	   		document.getElementById('formFormulaRE').style.display='none'; 
               	   		document.getElementById('formFormulaIE').style.display='none'; 
                    	                    	
                    	document.getElementById('formRevConceitual').style.display='none';
                    	document.getElementById('formPFA').style.display='none';
                    	document.getElementById('formRE').style.display='none';
                    	document.getElementById('formIE').style.display='none';
                    	document.getElementById('formFileName').style.display='none';                   	
                    	document.getElementById('formDiagAtivExerc').style.display='none';
                    	document.getElementById('formDiagNutMetab').style.display='none';
                    	document.getElementById('formDiagCogPercep').style.display='none';
                    	document.getElementById('formDiagSonoRep').style.display='none';
                    	document.getElementById('formDiagPercepCtrlSaude').style.display='none';
                    	document.getElementById('formDiagEliminacoes').style.display='none';
                    	document.getElementById('formDiagAutoPercepAutoConceito').style.display='none';
                    	document.getElementById('formDiagSexReprod').style.display='none';
                    	document.getElementById('formDiagPapelRel').style.display='none';
                    	document.getElementById('formDiagEnfrentEstresse').style.display='none';
                    	document.getElementById('formDiagValorCrenca').style.display='none';                    	                   	
                    	document.getElementById('formPFAEscolhido').style.display='none';
                    	document.getElementById('formIdentificacao').style.display='none';
                       	document.getElementById('formAntecedentesPF').style.display='none';
                       	
                       	document.getElementById('formHistoriaAtual').style.display='none';
                       	document.getElementById('formExameFisico').style.display='block';
                       	
                       	
                    }
                 
                    
               