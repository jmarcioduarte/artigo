package modelovetorial;



public class Bigrama {
	
	String word1;
	String word2;
	double totalTermos;
	
	double probWord1;
	double probWord2;
	double probWord1Word2;
	
	double totalWord1;
	double totalWord2;
	double totalBigrama;
	
	double pmi;
	
	boolean counted;
	
	public Bigrama(String word1, String word2, int totalTermos){
		
		this.word1 = word1;
		this.word2 = word2;
		this.totalTermos = totalTermos;
	}
    
	public void calculoFrequencia(){
		
		
		
	
	}
	
	
	
	public void probWord1(double totalWord1){
		this.totalWord1 = totalWord1;
		this.probWord1 = totalWord1/this.totalTermos;
		
	}
	
	public void probWord2(double totalWord2){
		this.totalWord2 = totalWord2;
		//this.probWord2 = Math.pow(totalWord2, 0.75)/Math.pow(this.totalTermos, 0.75);
		this.probWord2 = totalWord2/this.totalTermos;
	
	}
	
	public void probWord1Word2(double totalBigrama){
		
		this.totalBigrama = totalBigrama;
		this.probWord1Word2 = this.totalBigrama/(this.totalTermos);
		
		
	}
	
	public void calculoPMI() {
		//if(this.totalWord1 >3 && this.totalWord2 >3)
			pmi = Math.max(Math.log(this.probWord1Word2/(this.probWord1*this.probWord2 ))/Math.log(2), 0);		
		//else
		//	pmi = 0;
		
	}
	
	public void calculoPMI2() {
		//if(this.totalWord1 >3 && this.totalWord2 >3)
			pmi = Math.log(Math.pow(this.probWord1Word2,2)/(this.probWord1*this.probWord2 ))/Math.log(2);		
		//else
		//	pmi = 0;
		
	}
	
	public void calculoPMI3() {
		//if(this.totalWord1 >3 && this.totalWord2 >3)
			pmi = Math.log(Math.pow(this.probWord1Word2,3)/(this.probWord1*this.probWord2 ))/Math.log(2);		
		//else
		//	pmi = 0;
		
	}
	
	public void calculoPMI4() {
		//if(this.totalWord1 >3 && this.totalWord2 >3)
			double logNegatPab;
			pmi = Math.log(this.probWord1Word2/(this.probWord1*this.probWord2 ))/Math.log(2);
			logNegatPab = (-1.0)*Math.log(this.probWord1Word2)/Math.log(2);
			
			pmi = pmi/logNegatPab;
		//else
		//	pmi = 0;
		
	}
	
	public void calculoPMI5() {
		//if(this.totalWord1 >3 && this.totalWord2 >3)
			pmi = Math.log(this.probWord1Word2/(this.probWord1*this.probWord2 ))/Math.log(2);		
	//	else
		//	pmi = 0;
		
	}
	
	

	public String getWord1() {
		return word1;
	}

	public void setWord1(String word1) {
		this.word1 = word1;
	}

	public String getWord2() {
		return word2;
	}

	public void setWord2(String word2) {
		this.word2 = word2;
	}

	public double getProbWord1() {
		return probWord1;
	}

	public void setProbWord1(double probWord1) {
		this.probWord1 = probWord1;
	}

	public double getProbWord2() {
		return probWord2;
	}

	public void setProbWord2(double probWord2) {
		this.probWord2 = probWord2;
	}

	public double getProbWord1Word2() {
		return probWord1Word2;
	}

	public void setProbWord1Word2(double probWord1Word2) {
		this.probWord1Word2 = probWord1Word2;
	}

	public double getTotalWord1() {
		return totalWord1;
	}

	public void setTotalWord1(int totalWord1) {
		this.totalWord1 = totalWord1;
	}

	public double getTotalWord2() {
		return totalWord2;
	}

	public void setTotalWord2(int totalWord2) {
		this.totalWord2 = totalWord2;
	}

	public boolean isCounted() {
		return counted;
	}

	public void setCounted(boolean counted) {
		this.counted = counted;
	}

	public double getTotalBigrama() {
		return totalBigrama;
	}

	public void setTotalBigrama(double totalBigrama) {
		this.totalBigrama = totalBigrama;
	}

	public double getPmi() {
		return pmi;
	}

	public void setPmi(double pmi) {
		this.pmi = pmi;
	}
	
	
	
	
	
	

}
