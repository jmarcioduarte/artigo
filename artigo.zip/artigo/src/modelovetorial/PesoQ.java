package modelovetorial;


public class PesoQ {
	
	
	double tFreq;
	double idf;
	String word1;
	double pmi;
	
	double q;

	public PesoQ(String word1) {
		
		this.word1 = word1;
		
		
	}
	
	
	public void calculoPeso() {
		this.q = this.tFreq*this.idf;
	}

	
	




	public double gettFreq() {
		return tFreq;
	}


	public void settFreq(double tFreq) {
		this.tFreq = tFreq;
		
		this.tFreq = (0.5 + this.tFreq*1000/2);
	}


	public double getIdf() {
		return idf;
	}


	public void setIdf(double idf) {
		this.idf = idf;
	}


	public String getWord1() {
		return word1;
	}


	public void setWord1(String word1) {
		this.word1 = word1;
	}


	public double getQ() {
		return q;
	}


	public void setQ(double q) {
		this.q = q;
	}


	public double getPmi() {
		return pmi;
	}


	public void setPmi(double pmi) {
		this.pmi = pmi;
	}

	
	


	

}
