                   
                 
                 
                 function hideForms(){               	                   	    
                 	document.getElementById('formArquivo').style.display='block';
                 	document.getElementById('formRelatorio').style.display='none';
                 	document.getElementById('formPontuacao').style.display='none';                    
                }
                
               
               function visibleFormRelatorio(){               	   	               	   
                    	
                    	document.getElementById('formRelatorio').style.display='block';
                    	document.getElementById('formPontuacao').style.display='none';	                   	                   
              }
               
              function visibleFormPontuacao(){               	   	               	   
                    	
                    	document.getElementById('formRelatorio').style.display='none';
                    	document.getElementById('formPontuacao').style.display='block';	                   	                   
            } 