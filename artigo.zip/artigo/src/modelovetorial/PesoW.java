package modelovetorial;



public class PesoW {
	
	
	double tFreq;
	double idf;
	String word1;
	double pmi;
	
	double w;

	public PesoW(String word1) {
		
		this.word1 = word1;
		
		
	}
	
	
	public void calculoPeso() {
		this.w = this.tFreq*1000*this.idf;
	}

	
	




	public double gettFreq() {
		return tFreq;
	}


	public void settFreq(double tFreq) {
		this.tFreq = tFreq;
	}


	public double getIdf() {
		return idf;
	}


	public void setIdf(double idf) {
		this.idf = idf;
	}


	public String getWord1() {
		return word1;
	}


	public void setWord1(String word1) {
		this.word1 = word1;
	}


	public double getW() {
		return w;
	}


	public void setW(double w) {
		this.w = w;
	}


	public double getPmi() {
		return pmi;
	}


	public void setPmi(double pmi) {
		this.pmi = pmi;
	}


	


	

}
