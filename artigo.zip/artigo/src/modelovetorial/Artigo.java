package modelovetorial;

import java.util.ArrayList;

import java.util.TreeMap;



public class Artigo {
	
	TreeMap<String, Integer> ft;
	TreeMap<String, Double> idf;
	

	ArrayList<String> artigo;
	ArrayList<String> artigoTemp;
	ArrayList<String> queryList;
	ArrayList<ArrayList<String>> listaArtigos;
	ArrayList<Bigrama> bigrama;
	ArrayList<SimilaridadeCoseno> listaCoseno;
	ArrayList<PesoQ> vectorQ;
	TreeMap<String, Double> vectorW;
	
	double maxCoseno= -1.0;
	double cosseno;
	int qtdTotalTermos;
	public Artigo(ArrayList<String> artigo, ArrayList<ArrayList<String>> listaArtigos) {
		
		this.artigo = artigo;
		
		
		this.listaArtigos = listaArtigos;
		ft =  new TreeMap<String, Integer>();
		idf =  new TreeMap<String, Double>();
		listaCoseno = new ArrayList<SimilaridadeCoseno>();
		
	}
	
	public Artigo(ArrayList<String> artigo, ArrayList<ArrayList<String>> listaArtigos, ArrayList<String> queryList, int qtdTotalTermos) {
		
		this.artigo = artigo;
		this.qtdTotalTermos = qtdTotalTermos;
		
		this.listaArtigos = listaArtigos;
		ft =  new TreeMap<String, Integer>();
		idf =  new TreeMap<String, Double>();
		listaCoseno = new ArrayList<SimilaridadeCoseno>();
		
		this.queryList = queryList;
		
	}
	
	public void frequenciaTermos() {
		int contador;
		this.artigoTemp = new ArrayList<String>();
		
		for(int i=0; i<this.artigo.size(); i++)
			this.artigoTemp.add(artigo.get(i));
		
		
		
		for(int i=0; i<this.artigoTemp.size(); i++) {
			  
			contador=1;
			for(int j=i+1; j<this.artigoTemp.size();j++) {
				
				if(this.artigoTemp.get(i).equals(this.artigoTemp.get(j))==true ) {
				//	this.artigo.set(j, "-1");
					this.artigoTemp.remove(j);
					j--;
					contador++;
					
				}
			}
			ft.put(this.artigoTemp.get(i), contador);
		}	
		
	//	System.out.println("total termos artigo "+artigo.size());	
		//System.out.println(ft.size());
         //   System.out.println(ft);
    

	}
	
	public void idf() {
		double contador;
		double idfTemp;
		//TreeMap<String, Double> idft =  new TreeMap<String, Double>();
	//	System.out.println("qtde Artigos "+this.listaArtigos.size());
		for(int i=0; i<this.artigoTemp.size(); i++) {
			contador=0;
			for(int j=0; j<this.listaArtigos.size(); j++) {
				for(int z=0; z<this.listaArtigos.get(j).size(); z++) {
				
					if(this.artigoTemp.get(i).equals(this.listaArtigos.get(j).get(z))==true ) {
						
						contador++;
						break;
					}
				}	
			}
			//ALTERAR A QUANTIDADE DE ARTIGOS LERARQUIVOCORPUS
				
			if(contador==this.listaArtigos.size())
				idfTemp = 1.0;
			else
				idfTemp = Math.log((this.listaArtigos.size()/contador))/Math.log(2);
			//System.out.println("t "+this.artigoTemp.get(i)+" q "+contador+" log "+idfTemp);
			idf.put(this.artigoTemp.get(i), idfTemp);
			//idft.put(this.artigoTemp.get(i), contador);
			
		}	
		//System.out.println(idft);
		
		//System.out.println(idf);
	}
	
	
	
	
	public void pmi(int k) {
	
		this.bigrama = new ArrayList<Bigrama>();
		
		//for(int i=0; i<this.artigoTemp.size(); i++) 
		//	System.out.println(this.artigoTemp.get(i)+" "+ft.get(this.artigoTemp.get(i)));
		
		//for(int i=0; i<this.artigo.size(); i++) 
		//	System.out.println(this.artigo.get(i)+" "+ft.get(this.artigo.get(i)));
		
		for(int i=0; i<this.artigo.size()-1; i=i+1) {
			
				//contador = contador +ft.get(this.artigoTemp.get(i));
				Bigrama b = new Bigrama(this.artigo.get(i), this.artigo.get(i+1), this.qtdTotalTermos);
				b.probWord1(ft.get(this.artigo.get(i)));
				b.probWord2(ft.get(this.artigo.get(i+1)));
				this.bigrama.add(b);
			
		}
		//System.out.println("Cont "+this.bigrama.size());
		//System.out.println("art "+this.artigo.size());
		int contaBigrama;
		for(int i=0; i<this.bigrama.size(); i++) {
			contaBigrama =1;
			for(int j=i+1; j<this.bigrama.size();j++) {
				
				if(this.bigrama.get(i).getWord1().equals(this.bigrama.get(j).getWord1())==true &&
						this.bigrama.get(i).getWord2().equals(this.bigrama.get(j).getWord2())==true ||
						this.bigrama.get(i).getWord1().equals(this.bigrama.get(j).getWord2())==true &&
						this.bigrama.get(i).getWord2().equals(this.bigrama.get(j).getWord1())==true) {
						
					this.bigrama.remove(j);
						j--;
						contaBigrama = contaBigrama + 1;
					
				}
				
			
			}
			
			this.bigrama.get(i).probWord1Word2(contaBigrama);
			if(k==1)
				this.bigrama.get(i).calculoPMI();
			else if(k==2)
				this.bigrama.get(i).calculoPMI2();
			else if(k==3)
				this.bigrama.get(i).calculoPMI3();
			else if(k==4)
				this.bigrama.get(i).calculoPMI4();
			else if(k==5)
				this.bigrama.get(i).calculoPMI5();
			
		}
		
		/*for(int i=0; i<this.bigrama.size(); i++) {
	
			
				System.out.println("---------");
				System.out.println(bigrama.get(i).getWord1()+" "+bigrama.get(i).getWord2());
				System.out.println(bigrama.get(i).getTotalWord1()+" "+bigrama.get(i).getTotalWord2());
				System.out.println(bigrama.get(i).getProbWord1()+" "+bigrama.get(i).getProbWord2());
				System.out.println(bigrama.get(i).getTotalBigrama());
				System.out.println(bigrama.get(i).getProbWord1Word2());
				System.out.println("PMI "+bigrama.get(i).getPmi());
				
		
		}	*/
		
		
			
	}
	
	
	
public void calculoCosenoNovo() {
		
		PesoW w;
		ArrayList<PesoQ> vectorQ = new ArrayList<PesoQ>();
		ArrayList<ArrayList<PesoW>> listaVectorW = new ArrayList<ArrayList<PesoW>>();
		ArrayList<PesoW> vectorW = null;
			
			
		for(int j=0; j<this.queryList.size(); j++) {
		//	System.out.println("************************ ");
		//	System.out.println("TERMO "+this.queryList.get(j));
			vectorW = new ArrayList<PesoW>();
			for(int i=0; i<this.bigrama.size();i++) {
				
					
					
					if(this.queryList.get(j).equals(this.bigrama.get(i).getWord1())==true) {
						//System.out.println("w1 "+this.bigrama.get(i).getWord1()+" w2 "+this.bigrama.get(i).getWord2()+" pmi "+
											//			this.bigrama.get(i).getPmi());
					
						w = new PesoW(this.bigrama.get(i).getWord2());
						w.setPmi(this.bigrama.get(i).getPmi());
						vectorW.add(w);
						
						
						
					}
					else if (this.queryList.get(j).equals(this.bigrama.get(i).getWord2())==true){
						//System.out.println("else if w1 "+this.bigrama.get(i).getWord1()+" w2 "+this.bigrama.get(i).getWord2()+" pmi "+
								//this.bigrama.get(i).getPmi());
						
						
						w = new PesoW(this.bigrama.get(i).getWord1());
						w.setPmi(this.bigrama.get(i).getPmi());
						vectorW.add(w);
						
						
						
					}
					else {
						w = new PesoW(this.bigrama.get(i).getWord1());
						w.setPmi(0.0);
						vectorW.add(w);
					//	System.out.println("else w1 "+this.bigrama.get(i).getWord1()+" w2 "+this.bigrama.get(i).getWord2()+" pmi "+
						//		0);
						
						
					}
				}		
			listaVectorW.add(vectorW);
				
			}
		/*	while(vectorW.size()<this.qtdTotalTermos) {
				w = new PesoW("SI");
				w.setPmi(0.0);
				vectorW.add(w);
				
				q = new PesoQ("SI");
				q.setPmi(100.0);
				vectorQ.add(q);
			}*/
		//	System.out.println("total Ter"+this.qtdTotalTermos);
		//	System.out.println("vectorW "+vectorW.size());
		//	System.out.println("vectorQ "+vectorQ.size());
			
			
			SimilaridadeCoseno sc = new SimilaridadeCoseno(vectorQ,	vectorW, listaVectorW);
			sc.calculoCoseno();
			this.maxCoseno = sc.getCosseno();
	}
	
	
	public void modeloVetorialTradicional() {
		
		PesoW w;
		vectorW = new TreeMap<String, Double>();
		double temp;
		for(int i=0; i<this.artigoTemp.size(); i++) {
			
			
			w = new PesoW(this.artigoTemp.get(i));
			temp = this.ft.get(this.artigoTemp.get(i));
			temp = temp/this.artigo.size();
			
			w.settFreq(temp);
			w.setIdf(this.idf.get(this.artigoTemp.get(i)));
			w.calculoPeso();
			this.vectorW.put(this.artigoTemp.get(i), w.getW());
			
			
		}
	//	System.out.println(this.artigo.size());
		/*for(int i=0; i<vectorW.size(); i++) {
		//	System.out.println(vectorW.get(i).getWord1()+ " "+this.ft.get(vectorW.get(i).getWord1()));
			
			System.out.println(vectorW.get(i).gettFreq());
			System.out.println(vectorW.get(i).getIdf());
			System.out.println(vectorW.get(i).getW());
			System.out.println("***********************");
		}*/
		
	}
	
	
	public void CalculoPesoQuery() {
		
		PesoQ q;
		vectorQ = new ArrayList<PesoQ>();
		double temp;
		
		for(int i=0; i<this.queryList.size(); i++) {
			
			
			q = new PesoQ(this.queryList.get(i));
			if(this.ft.get(this.queryList.get(i))!=null)
					temp = this.ft.get(this.queryList.get(i));
			else
					temp=this.artigo.size();
			
			temp = temp/this.artigo.size();
		//	System.out.println("qtdterm "+this.artigo.size()+" termo "+this.queryList.get(i)+ " freq ab "+this.ft.get(this.queryList.get(i))+ " freq rela "+temp);
		//	System.out.println("idf "+this.idf.get(this.queryList.get(i)));
			q.settFreq(temp);
			if(this.idf.get(this.queryList.get(i))!=null)
				q.setIdf(this.idf.get(this.queryList.get(i)));
			else
				q.setIdf(1.0);
			
			q.calculoPeso();
			this.vectorQ.add(q);
			
		}
		
		/*for(int i=0; i<vectorQ.size(); i++) {
			    System.out.println(vectorQ.get(i).getWord1()+ " "+this.ft.get(vectorQ.get(i).getWord1()));
				
				System.out.println(vectorQ.get(i).gettFreq());
				System.out.println(vectorQ.get(i).getIdf());
				System.out.println(vectorQ.get(i).getQ());
				System.out.println("***********************");
		}*/
		
	}
	
	public void similaridCosenoNormal() {
		
		
		SimilaridadeCosenoNormal scNormal = new SimilaridadeCosenoNormal(this.vectorQ, this.vectorW); 
		scNormal.calculoCoseno();
		this.cosseno = scNormal.getCosseno();
	}

	public double getMaxCoseno() {
		return maxCoseno;
	}

	public void setMaxCoseno(double maxCoseno) {
		this.maxCoseno = maxCoseno;
	}

	public TreeMap<String, Integer> getFt() {
		return ft;
	}

	public void setFt(TreeMap<String, Integer> ft) {
		this.ft = ft;
	}

	public double getCosseno() {
		return cosseno;
	}

	public void setCosseno(double cosseno) {
		this.cosseno = cosseno;
	}
	
	
/*	public void calculoCosenoNovo() {
		PesoQ q;
		PesoW w;
		ArrayList<PesoQ> vectorQ = new ArrayList<PesoQ>();
		ArrayList<PesoW> vectorW = new ArrayList<PesoW>();
			
			
			
			
			for(int i=0; i<this.bigrama.size();i++) {
				
				for(int j=0; j<this.queryList.size(); j++) {
					
					if(this.queryList.get(j).equals(this.bigrama.get(i).getWord1())==true) {
						//System.out.println("w1 "+this.bigrama.get(i).getWord1()+" w2 "+this.bigrama.get(i).getWord2()+" pmi "+
							//							this.bigrama.get(i).getPmi());
					
						w = new PesoW(this.bigrama.get(i).getWord2());
						w.setPmi(this.bigrama.get(i).getPmi());
						vectorW.add(w);
						
						q = new PesoQ(this.queryList.get(j));
						//q.setPmi(100.0);
						
						double temp;
						if(this.ft.get(this.queryList.get(j))!=null)
							temp = this.ft.get(this.queryList.get(j));
						else
							temp=this.artigo.size();
					
						temp = temp/this.artigo.size();
				
						q.settFreq(temp);
						if(this.idf.get(this.queryList.get(j))!=null)
							q.setIdf(this.idf.get(this.queryList.get(j)));
						else
							q.setIdf(1.0);
						q.calculoPeso();
						vectorQ.add(q);
						
					}
					else if (this.queryList.get(j).equals(this.bigrama.get(i).getWord2())==true){
						//System.out.println("else w1 "+this.bigrama.get(i).getWord1()+" w2 "+this.bigrama.get(i).getWord2()+" pmi "+
						//		this.bigrama.get(i).getPmi());
						
						
						w = new PesoW(this.bigrama.get(i).getWord1());
						w.setPmi(this.bigrama.get(i).getPmi());
						vectorW.add(w);
						
						q = new PesoQ(this.queryList.get(j));
						//q.setPmi(100.0);
						///vectorQ.add(q);
						
						double temp;
						if(this.ft.get(this.queryList.get(j))!=null)
							temp = this.ft.get(this.queryList.get(j));
						else
							temp=this.artigo.size();
					
						temp = temp/this.artigo.size();
				
						q.settFreq(temp);
						if(this.idf.get(this.queryList.get(j))!=null)
							q.setIdf(this.idf.get(this.queryList.get(j)));
						else
							q.setIdf(1.0);
						q.calculoPeso();
						vectorQ.add(q);
						
					}
					else {
						w = new PesoW(this.bigrama.get(i).getWord1());
						w.setPmi(0.0);
						vectorW.add(w);
						
						q = new PesoQ(this.queryList.get(j));
						q.setPmi(100.0);
						//q.setPmi(100.0);
						///vectorQ.add(q);
						
						double temp;
						if(this.ft.get(this.queryList.get(j))!=null)
							temp = this.ft.get(this.queryList.get(j));
						else
							temp=this.artigo.size();
					
						temp = temp/this.artigo.size();
				
						q.settFreq(temp);
						if(this.idf.get(this.queryList.get(j))!=null)
							q.setIdf(this.idf.get(this.queryList.get(j)));
						else
							q.setIdf(1.0);
						q.calculoPeso();
						vectorQ.add(q);
					}
				}		
				
				
			}
			while(vectorW.size()<this.qtdTotalTermos) {
				w = new PesoW("SI");
				w.setPmi(0.0);
				vectorW.add(w);
				
				q = new PesoQ("SI");
				q.setPmi(100.0);
				vectorQ.add(q);
			}
		//	System.out.println("total Ter"+this.qtdTotalTermos);
		//	System.out.println("vectorW "+vectorW.size());
		//	System.out.println("vectorQ "+vectorQ.size());
			
			
			SimilaridadeCoseno sc = new SimilaridadeCoseno(vectorQ,	vectorW);
			sc.calculoCoseno();
			this.maxCoseno = sc.getCosseno();
	}*/
	
}
