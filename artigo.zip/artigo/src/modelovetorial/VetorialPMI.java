package modelovetorial;

public class VetorialPMI {

}
