package modelovetorial;

import java.util.ArrayList;


public class SimilaridadeCoseno {
	
	
	ArrayList<PesoQ> vectorQ;
	ArrayList<PesoW> vectorW;
	ArrayList<ArrayList<PesoW>> listaVectorW;
	double cosseno=-100.0;
	public SimilaridadeCoseno(ArrayList<PesoQ> vectorQ,	ArrayList<PesoW> vectorW, ArrayList<ArrayList<PesoW>> listaVectorW) {
		
		this.vectorQ = vectorQ;
		this.vectorW = vectorW;
		this.listaVectorW = listaVectorW;
	}
	
	public void calculoCoseno() {
		
		double vw = 0;
		double v = 0;
		double w = 0;
		int v1;
		
		//System.out.println("lista vetores "+this.listaVectorW.size());
		for(int i=0; i<this.listaVectorW.size();i++) {
			v1 = i+1;
			while (v1 < this.listaVectorW.size()) {
				for(int j=0; j<this.listaVectorW.get(i).size();j++) {
					
				//	System.out.println("j "+this.listaVectorW.get(i).get(j).getPmi());
				//	System.out.println("v "+this.listaVectorW.get(v1).get(j).getPmi());
					
					
						vw = vw + this.listaVectorW.get(i).get(j).getPmi()*this.listaVectorW.get(v1).get(j).getPmi();															
						w = w + this.listaVectorW.get(i).get(j).getPmi()*this.listaVectorW.get(i).get(j).getPmi();
						v = v + this.listaVectorW.get(v1).get(j).getPmi()*this.listaVectorW.get(v1).get(j).getPmi();
					
				
				}
				
				
				v = Math.sqrt(v);
				w = Math.sqrt(w);
				double temp;
				temp = vw/(v*w);
				if(this.cosseno < temp )
					this.cosseno =  temp;
				
				
				
				vw = 0.0;
				w = 0.0;
				v= 0.0;
				v1++;
			}
			
		}
		
		
	/*	
		for(int i=0; i<this.vectorW.size();i++) {
			
			
			//	vw = vw + this.vectorW.get(i).getPmi()*this.vectorQ.get(i).getPmi();
				
				vw = vw + this.vectorW.get(i).getPmi()*this.vectorQ.get(i).getQ();
				
			//	w = w + this.vectorW.get(i).getPmi()*this.vectorW.get(i).getPmi();
			//	v = v + this.vectorQ.get(i).getPmi()*this.vectorQ.get(i).getPmi();
				
				w = w + this.vectorW.get(i).getPmi()*this.vectorW.get(i).getPmi();
				v = v + this.vectorQ.get(i).getPmi()*this.vectorQ.get(i).getQ();
				
				
			}
			*/
		
		
	//	System.out.println("vw "+vw);
	//	System.out.println("v "+v);
	//	System.out.println("w "+w);
		/*v = Math.sqrt(v);
		w = Math.sqrt(w);
		
		this.cosseno = vw/(v*w);*/
	//	System.out.println("cosseno "+cosseno);
	}

	public double getCosseno() {
		return cosseno;
	}

	public void setCosseno(double cosseno) {
		this.cosseno = cosseno;
	}
	
	

}
