package modelovetorial;

public class ElementoMatriz {
	
	String word1, word2;
	double valorPMI;
	public ElementoMatriz(String word1, String word2) {
		
		this.word1 = word1;
		this.word2 = word2;
	}
	
	
	public double getValorPMI() {
		return valorPMI;
	}
	public void setValorPMI(double valorPMI) {
		this.valorPMI = valorPMI;
	}


	public String getWord1() {
		return word1;
	}


	public void setWord1(String word1) {
		this.word1 = word1;
	}


	public String getWord2() {
		return word2;
	}


	public void setWord2(String word2) {
		this.word2 = word2;
	}
	
	
	
	

}
