package modelovetorial;

import java.util.ArrayList;
import java.util.TreeMap;

public class SimilaridadeCosenoNormal {
	
	VectorPMI v;
	VectorPMI w;
	TreeMap<String, Double> vectorW;
	
	double cosseno;
	
	ArrayList<PesoQ> vectorQ;
	
	
	public SimilaridadeCosenoNormal(ArrayList<PesoQ> vectorQ, TreeMap<String, Double> vectorW) {
		this.vectorQ = vectorQ;
		this.vectorW = vectorW;
	}
	
	public void calculoCoseno() {
		double qw = 0;
		double q = 0;
		double w = 0;
		
		for(int i=0; i<this.vectorQ.size();i++) {
		//	System.out.println("termo query "+this.vectorQ.get(i).getWord1()+" peso "+this.vectorQ.get(i).getQ());
			
			if(this.vectorW.get(this.vectorQ.get(i).getWord1())!=null) {				
				qw = qw + this.vectorQ.get(i).getQ()*this.vectorW.get(this.vectorQ.get(i).getWord1());
			
				w = w + this.vectorW.get(this.vectorQ.get(i).getWord1())*this.vectorW.get(this.vectorQ.get(i).getWord1());
				
			//	System.out.println("termo w "+this.vectorQ.get(i).getWord1()+ " peso w "+this.vectorW.get(this.vectorQ.get(i).getWord1()));
			}
			else {
				qw = qw + this.vectorQ.get(i).getQ()*(0.0);
				w = w + 0.0;
				
				//System.out.println("termo w "+this.vectorQ.get(i).getWord1()+" peso w "+0);
			}
			q = q + this.vectorQ.get(i).getQ()*this.vectorQ.get(i).getQ();
		}
		//System.out.println("qw "+qw+ " q "+q +" w "+w);
		q = Math.sqrt(q);
		w = Math.sqrt(w);
		
		this.cosseno = qw/(q*w);	
			
		
		//System.out.println("COSSENO "+cosseno);
	}

	public double getCosseno() {
		return cosseno;
	}

	public void setCosseno(double cosseno) {
		this.cosseno = cosseno;
	}
	
	

}
