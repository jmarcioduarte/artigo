package com.caccWeb.managedbean;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.TreeMap;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import com.caccWeb.arquivo.LerArquivoCorpus;
import com.caccWeb.cogroo.PreProcessamentoStemmer;
import com.caccWeb.cogroo.PreProcessamentoStemmerQuery;

import modelovetorial.Artigo;
import modelovetorial.Documento;





/**
 * @author jm.duarte
 *
 */

@ManagedBean(name="modelovetorial")
@SessionScoped
public class VectorModelBean  {

	String query;
	
	double inicio, fim;


	public VectorModelBean(){
		
	}
	
	
	
	public String positivePointWise(){
	
	
		
		ArrayList<ArrayList<String>> listaArtigos = new ArrayList<ArrayList<String>>();
		ArrayList<ArrayList<String>> listaArtigosTokens = new ArrayList<ArrayList<String>>();
		ArrayList<ArrayList<String>> listaArtigosSemSW = new ArrayList<ArrayList<String>>();
		ArrayList<ArrayList<String>> listaArtigosTokensFinal = new ArrayList<ArrayList<String>>();
		ArrayList<ArrayList<String>> listaArtigosStem = new ArrayList<ArrayList<String>>();
		
		
		
		LerArquivoCorpus ler = new LerArquivoCorpus();
		listaArtigos = ler.lerArquivo();
		
		
		ArrayList<String> listaQueryStem = new ArrayList<String>();
		

		PreProcessamentoStemmerQuery preProcessQuery = new PreProcessamentoStemmerQuery();
		
		listaQueryStem = preProcessQuery.stemmer(this.query);
		
		PreProcessamentoStemmer preProcess = new PreProcessamentoStemmer();
		try {
			
			listaArtigosTokens =preProcess.tokenizer(listaArtigos);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		listaArtigosSemSW = preProcess.removeStopWords(listaArtigosTokens);
		try {
			listaArtigosTokensFinal = preProcess.tokenizerFinal(listaArtigosSemSW);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		listaArtigosStem = preProcess.stemmer(listaArtigosTokensFinal);
		ArrayList<Documento> listaCossenos = new ArrayList<Documento>();
		
		System.out.println("\n POSITIVE PMI");
		this.inicio = System.currentTimeMillis();
		
		for (int i=0; i<51; i++) {
			Artigo art = new Artigo(listaArtigosStem.get(i), listaArtigosStem, listaQueryStem, preProcess.getQtdeTotalTermos());
			art.frequenciaTermos();
			art.idf();
			art.pmi(1);
			
		
			art.calculoCosenoNovo();
			listaCossenos.add(new Documento((i+1),art.getMaxCoseno()));
		}
		this.fim = System.currentTimeMillis();		
		System.out.println("Tempo "+(fim - inicio));
		
		double cosseno;
		int  doc;
		for (int i=0; i<listaCossenos.size();i++) {
			for(int j=i+1; j<listaCossenos.size();j++ ) {
				if(listaCossenos.get(i).getCosseno()<listaCossenos.get(j).getCosseno()) {
					cosseno = listaCossenos.get(i).getCosseno();
					doc = listaCossenos.get(i).getDoc();
					listaCossenos.get(i).setCosseno(listaCossenos.get(j).getCosseno());
					listaCossenos.get(i).setDoc(listaCossenos.get(j).getDoc());
					
					listaCossenos.get(j).setCosseno(cosseno);
					listaCossenos.get(j).setDoc(doc);
					
				}
			}
		}
		
		for (int i=0; i<listaCossenos.size();i++) {
			System.out.println("Artigo "+listaCossenos.get(i).getDoc());
			System.out.println("cosseno "+listaCossenos.get(i).getCosseno());
		
		}	
		
		
		return null;
	}
	
	
	public String vetorial(){
	
		//System.out.println("query "+this.query);
		
		ArrayList<ArrayList<String>> listaArtigos = new ArrayList<ArrayList<String>>();
		ArrayList<ArrayList<String>> listaArtigosTokens = new ArrayList<ArrayList<String>>();
		ArrayList<ArrayList<String>> listaArtigosSemSW = new ArrayList<ArrayList<String>>();
		ArrayList<ArrayList<String>> listaArtigosTokensFinal = new ArrayList<ArrayList<String>>();
		ArrayList<ArrayList<String>> listaArtigosStem = new ArrayList<ArrayList<String>>();
		
		ArrayList<String> listaQueryStem = new ArrayList<String>();
		
		
		LerArquivoCorpus ler = new LerArquivoCorpus();
		listaArtigos = ler.lerArquivo();
		
		
		PreProcessamentoStemmerQuery preProcessQuery = new PreProcessamentoStemmerQuery();
		
		listaQueryStem = preProcessQuery.stemmer(this.query);
		
		PreProcessamentoStemmer preProcess = new PreProcessamentoStemmer();
		try {
			
			listaArtigosTokens =preProcess.tokenizer(listaArtigos);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		listaArtigosSemSW = preProcess.removeStopWords(listaArtigosTokens);
		try {
			listaArtigosTokensFinal = preProcess.tokenizerFinal(listaArtigosSemSW);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		listaArtigosStem = preProcess.stemmer(listaArtigosTokensFinal);
		ArrayList<Documento> listaCossenos = new ArrayList<Documento>();
		
		System.out.println("\n VETORIAL");
		this.inicio = System.currentTimeMillis();
		
		for (int i=0; i<51; i++) {
			Artigo art = new Artigo(listaArtigosStem.get(i), listaArtigosStem, listaQueryStem, preProcess.getQtdeTotalTermos());
			art.frequenciaTermos();
			art.idf();
			
			art.modeloVetorialTradicional();
			art.CalculoPesoQuery();
		//	System.out.println("Artigo "+(i+1));
			art.similaridCosenoNormal();
			listaCossenos.add(new Documento((i+1), art.getCosseno()));
			
		//	System.out.println("max cos "+art.getMaxCoseno()*100.0);
			
		}
		this.fim = System.currentTimeMillis();		
		System.out.println("Tempo "+(fim - inicio));
		
		double cosseno;
		int  doc;
		for (int i=0; i<listaCossenos.size();i++) {
			for(int j=i+1; j<listaCossenos.size();j++ ) {
				if(listaCossenos.get(i).getCosseno()<listaCossenos.get(j).getCosseno()) {
					cosseno = listaCossenos.get(i).getCosseno();
					doc = listaCossenos.get(i).getDoc();
					listaCossenos.get(i).setCosseno(listaCossenos.get(j).getCosseno());
					listaCossenos.get(i).setDoc(listaCossenos.get(j).getDoc());
					
					listaCossenos.get(j).setCosseno(cosseno);
					listaCossenos.get(j).setDoc(doc);
					
				}
			}
		}
		
		for (int i=0; i<listaCossenos.size();i++) {
			System.out.println("Artigo "+listaCossenos.get(i).getDoc());
			System.out.println("cosseno "+listaCossenos.get(i).getCosseno());
		
		}	
		return null;
	}
	
	
public String pmi2(){
	
	
		
		ArrayList<ArrayList<String>> listaArtigos = new ArrayList<ArrayList<String>>();
		ArrayList<ArrayList<String>> listaArtigosTokens = new ArrayList<ArrayList<String>>();
		ArrayList<ArrayList<String>> listaArtigosSemSW = new ArrayList<ArrayList<String>>();
		ArrayList<ArrayList<String>> listaArtigosTokensFinal = new ArrayList<ArrayList<String>>();
		ArrayList<ArrayList<String>> listaArtigosStem = new ArrayList<ArrayList<String>>();
		
		
		
		
		
		LerArquivoCorpus ler = new LerArquivoCorpus();
		listaArtigos = ler.lerArquivo();
		
		
		ArrayList<String> listaQueryStem = new ArrayList<String>();
		

		PreProcessamentoStemmerQuery preProcessQuery = new PreProcessamentoStemmerQuery();
		
		listaQueryStem = preProcessQuery.stemmer(this.query);
		
		PreProcessamentoStemmer preProcess = new PreProcessamentoStemmer();
		try {
			
			listaArtigosTokens =preProcess.tokenizer(listaArtigos);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		listaArtigosSemSW = preProcess.removeStopWords(listaArtigosTokens);
		try {
			listaArtigosTokensFinal = preProcess.tokenizerFinal(listaArtigosSemSW);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		listaArtigosStem = preProcess.stemmer(listaArtigosTokensFinal);
		ArrayList<Documento> listaCossenos = new ArrayList<Documento>();
		System.out.println("\n PMI 2");
		
		this.inicio = System.currentTimeMillis();
		
		for (int i=0; i<51; i++) {
			Artigo art = new Artigo(listaArtigosStem.get(i), listaArtigosStem, listaQueryStem, preProcess.getQtdeTotalTermos());
			art.frequenciaTermos();
			art.idf();
			art.pmi(2);
			art.calculoCosenoNovo();
			listaCossenos.add(new Documento((i+1),art.getMaxCoseno()));
			
		}
		this.fim = System.currentTimeMillis();		
		System.out.println("Tempo "+(fim - inicio));
		
		double cosseno;
		int  doc;
		for (int i=0; i<listaCossenos.size();i++) {
			for(int j=i+1; j<listaCossenos.size();j++ ) {
				if(listaCossenos.get(i).getCosseno()<listaCossenos.get(j).getCosseno()) {
					cosseno = listaCossenos.get(i).getCosseno();
					doc = listaCossenos.get(i).getDoc();
					listaCossenos.get(i).setCosseno(listaCossenos.get(j).getCosseno());
					listaCossenos.get(i).setDoc(listaCossenos.get(j).getDoc());
					
					listaCossenos.get(j).setCosseno(cosseno);
					listaCossenos.get(j).setDoc(doc);
					
				}
			}
		}
		
		for (int i=0; i<listaCossenos.size();i++) {
			System.out.println("Artigo "+listaCossenos.get(i).getDoc());
			System.out.println("cosseno "+listaCossenos.get(i).getCosseno());
		
		}	
		
		return null;
	}
	
	
public String pmi3(){
	
	
	
	ArrayList<ArrayList<String>> listaArtigos = new ArrayList<ArrayList<String>>();
	ArrayList<ArrayList<String>> listaArtigosTokens = new ArrayList<ArrayList<String>>();
	ArrayList<ArrayList<String>> listaArtigosSemSW = new ArrayList<ArrayList<String>>();
	ArrayList<ArrayList<String>> listaArtigosTokensFinal = new ArrayList<ArrayList<String>>();
	ArrayList<ArrayList<String>> listaArtigosStem = new ArrayList<ArrayList<String>>();
	
	
	
	LerArquivoCorpus ler = new LerArquivoCorpus();
	listaArtigos = ler.lerArquivo();
	
	
	ArrayList<String> listaQueryStem = new ArrayList<String>();
	

	PreProcessamentoStemmerQuery preProcessQuery = new PreProcessamentoStemmerQuery();
	
	listaQueryStem = preProcessQuery.stemmer(this.query);
	
	PreProcessamentoStemmer preProcess = new PreProcessamentoStemmer();
	try {
		
		listaArtigosTokens =preProcess.tokenizer(listaArtigos);
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	listaArtigosSemSW = preProcess.removeStopWords(listaArtigosTokens);
	try {
		listaArtigosTokensFinal = preProcess.tokenizerFinal(listaArtigosSemSW);
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	ArrayList<Documento> listaCossenos = new ArrayList<Documento>();
	
	listaArtigosStem = preProcess.stemmer(listaArtigosTokensFinal);
	System.out.println("\n POSITIVE PM3");
	
	this.inicio = System.currentTimeMillis();
	for (int i=0; i<51; i++) {
		Artigo art = new Artigo(listaArtigosStem.get(i), listaArtigosStem, listaQueryStem, preProcess.getQtdeTotalTermos());
		art.frequenciaTermos();
		art.idf();
		art.pmi(3);
		art.calculoCosenoNovo();
		listaCossenos.add(new Documento((i+1), art.getMaxCoseno()));
		
	}
	this.fim = System.currentTimeMillis();		
	System.out.println("Tempo "+(fim - inicio));
	
	double cosseno;
	int  doc;
	for (int i=0; i<listaCossenos.size();i++) {
		for(int j=i+1; j<listaCossenos.size();j++ ) {
			if(listaCossenos.get(i).getCosseno()<listaCossenos.get(j).getCosseno()) {
				cosseno = listaCossenos.get(i).getCosseno();
				doc = listaCossenos.get(i).getDoc();
				listaCossenos.get(i).setCosseno(listaCossenos.get(j).getCosseno());
				listaCossenos.get(i).setDoc(listaCossenos.get(j).getDoc());
				
				listaCossenos.get(j).setCosseno(cosseno);
				listaCossenos.get(j).setDoc(doc);
				
			}
		}
	}
	
	for (int i=0; i<listaCossenos.size();i++) {
		System.out.println("Artigo "+listaCossenos.get(i).getDoc());
		System.out.println("cosseno "+listaCossenos.get(i).getCosseno());
	
	}	
	
	return null;
}


public String npmi(){
	
	
	
	ArrayList<ArrayList<String>> listaArtigos = new ArrayList<ArrayList<String>>();
	ArrayList<ArrayList<String>> listaArtigosTokens = new ArrayList<ArrayList<String>>();
	ArrayList<ArrayList<String>> listaArtigosSemSW = new ArrayList<ArrayList<String>>();
	ArrayList<ArrayList<String>> listaArtigosTokensFinal = new ArrayList<ArrayList<String>>();
	ArrayList<ArrayList<String>> listaArtigosStem = new ArrayList<ArrayList<String>>();
	
	
	LerArquivoCorpus ler = new LerArquivoCorpus();
	listaArtigos = ler.lerArquivo();
	
	
	ArrayList<String> listaQueryStem = new ArrayList<String>();
	

	PreProcessamentoStemmerQuery preProcessQuery = new PreProcessamentoStemmerQuery();
	
	listaQueryStem = preProcessQuery.stemmer(this.query);
	
	PreProcessamentoStemmer preProcess = new PreProcessamentoStemmer();
	try {
		
		listaArtigosTokens =preProcess.tokenizer(listaArtigos);
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	listaArtigosSemSW = preProcess.removeStopWords(listaArtigosTokens);
	try {
		listaArtigosTokensFinal = preProcess.tokenizerFinal(listaArtigosSemSW);
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	listaArtigosStem = preProcess.stemmer(listaArtigosTokensFinal);
	ArrayList<Documento> listaCossenos = new ArrayList<Documento>();
	
	System.out.println("\n NPMI");
	this.inicio = System.currentTimeMillis();
	
	for (int i=0; i<51; i++) {
		Artigo art = new Artigo(listaArtigosStem.get(i), listaArtigosStem, listaQueryStem, preProcess.getQtdeTotalTermos());
		art.frequenciaTermos();
		art.idf();
		art.pmi(4);
		art.calculoCosenoNovo();
		listaCossenos.add(new Documento((i+1),art.getMaxCoseno()));
	
	}
	this.fim = System.currentTimeMillis();		
	System.out.println("Tempo "+(fim - inicio));
	
	double cosseno;
	int  doc;
	for (int i=0; i<listaCossenos.size();i++) {
		for(int j=i+1; j<listaCossenos.size();j++ ) {
			if(listaCossenos.get(i).getCosseno()<listaCossenos.get(j).getCosseno()) {
				cosseno = listaCossenos.get(i).getCosseno();
				doc = listaCossenos.get(i).getDoc();
				listaCossenos.get(i).setCosseno(listaCossenos.get(j).getCosseno());
				listaCossenos.get(i).setDoc(listaCossenos.get(j).getDoc());
				
				listaCossenos.get(j).setCosseno(cosseno);
				listaCossenos.get(j).setDoc(doc);
				
			}
		}
	}
	
	for (int i=0; i<listaCossenos.size();i++) {
		System.out.println("Artigo "+listaCossenos.get(i).getDoc());
		System.out.println("cosseno "+listaCossenos.get(i).getCosseno());
	
	}	
	
	return null;
}


public String pmi(){
	
	
	
	ArrayList<ArrayList<String>> listaArtigos = new ArrayList<ArrayList<String>>();
	ArrayList<ArrayList<String>> listaArtigosTokens = new ArrayList<ArrayList<String>>();
	ArrayList<ArrayList<String>> listaArtigosSemSW = new ArrayList<ArrayList<String>>();
	ArrayList<ArrayList<String>> listaArtigosTokensFinal = new ArrayList<ArrayList<String>>();
	ArrayList<ArrayList<String>> listaArtigosStem = new ArrayList<ArrayList<String>>();
	
	
	LerArquivoCorpus ler = new LerArquivoCorpus();
	listaArtigos = ler.lerArquivo();
	
	
	ArrayList<String> listaQueryStem = new ArrayList<String>();
	

	PreProcessamentoStemmerQuery preProcessQuery = new PreProcessamentoStemmerQuery();
	
	listaQueryStem = preProcessQuery.stemmer(this.query);
	
	PreProcessamentoStemmer preProcess = new PreProcessamentoStemmer();
	try {
		
		listaArtigosTokens =preProcess.tokenizer(listaArtigos);
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	listaArtigosSemSW = preProcess.removeStopWords(listaArtigosTokens);
	try {
		listaArtigosTokensFinal = preProcess.tokenizerFinal(listaArtigosSemSW);
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	listaArtigosStem = preProcess.stemmer(listaArtigosTokensFinal);
	ArrayList<Documento> listaCossenos = new ArrayList<Documento>();
	
	System.out.println("\n PMI");
	this.inicio = System.currentTimeMillis();
	
	for (int i=0; i<51; i++) {
		Artigo art = new Artigo(listaArtigosStem.get(i), listaArtigosStem, listaQueryStem, preProcess.getQtdeTotalTermos());
		art.frequenciaTermos();
		art.idf();
		art.pmi(5);
		
	
		art.calculoCosenoNovo();
		//listaArtigosPMI.add(art);
		//System.out.println("Artigo "+(i+1));
		//System.out.println("max cos "+art.getMaxCoseno()*100.0);
		listaCossenos.add(new Documento((i+1),art.getMaxCoseno()));
	}
	this.fim = System.currentTimeMillis();
	System.out.println("Tempo "+(fim - inicio));
	double cosseno;
	int  doc;
	for (int i=0; i<listaCossenos.size();i++) {
		for(int j=i+1; j<listaCossenos.size();j++ ) {
			if(listaCossenos.get(i).getCosseno()<listaCossenos.get(j).getCosseno()) {
				cosseno = listaCossenos.get(i).getCosseno();
				doc = listaCossenos.get(i).getDoc();
				listaCossenos.get(i).setCosseno(listaCossenos.get(j).getCosseno());
				listaCossenos.get(i).setDoc(listaCossenos.get(j).getDoc());
				
				listaCossenos.get(j).setCosseno(cosseno);
				listaCossenos.get(j).setDoc(doc);
				
			}
		}
	}
	
	for (int i=0; i<listaCossenos.size();i++) {
		System.out.println("Artigo "+listaCossenos.get(i).getDoc());
		System.out.println("cosseno "+listaCossenos.get(i).getCosseno());
	
	}	
	
	return null;
}
	
	public String getQuery() {
		return query;
	}



	public void setQuery(String query) {
		this.query = query;
	}

	
}
